# Code map

_Generated 2026-11-18T20:28Z at commit 3e76ef8 on develop. Do not edit by hand._

## Crates and web UI features

### crates/backtest - Event-driven backtester, cost model and walk-forward.
- `crates/backtest/src/lib.rs` - Event-driven backtester, cost model and walk-forward.

### crates/broker - Live Kite order executor behind the off-by-default live-trading feature.
- `crates/broker/src/lib.rs` - Live Kite order executor behind the off-by-default `live-trading` feature.

### crates/cli - Headless composition root (clap): check-connections, imports, backtest.
- `crates/cli/src/lib.rs` - Headless composition root (clap): check-connections, imports, backtest. | struct Cli
- `crates/cli/src/main.rs` - `bazaar-cli` binary: stub that parses the shared arguments.

### crates/core - Domain types, Money, IST Clock, MarketCalendar and config loading; depends on no internal crate.
- `crates/core/src/calendar.rs` - `MarketCalendar` built from `calendar.toml` ([`CalendarConfig`]). | enum CalendarError, enum Session, fn close_time, fn from_config, fn is_trading_day, fn next_trading_day, fn prev_trading_day, fn session_at, fn shift_to_prior_trading_day, struct MarketCalendar
- `crates/core/src/clock.rs` - The one `Clock` trait. All time-dependent code takes `&dyn Clock`; no wall-clock reads elsewhere. | struct SystemClock, trait Clock
- `crates/core/src/disclaimer.rs` - The permanent disclaimer constant, for exports and notifications. It must stay byte-equal to | const DISCLAIMER, fn with_disclaimer
- `crates/core/src/error.rs` - Domain error enum shared by the pure domain types. | enum DomainError
- `crates/core/src/lib.rs` - Domain types, `Money`, IST `Clock`, `MarketCalendar` and config loading; depends on no internal crate. | mod calendar, mod clock, mod config, mod disclaimer, mod error, mod mode, mod money, mod segment, mod testutil
- `crates/core/src/mode.rs` - Execution mode. Read only from `config/risk.toml` `[mode]`; never from an env var, CLI flag | const fn, enum ExecutionMode
- `crates/core/src/money.rs` - `Money`, `Price`, `Qty` and `Lots` over `Decimal`. No `f64` anywhere. | const ZERO, const fn, fn checked_add, fn checked_mul, fn checked_sub, fn notional, fn round_paise, fn snap_to_tick, fn to_qty, struct Lots, struct Money, struct Price, struct Qty
- `crates/core/src/segment.rs` - Market segment and instrument kind. Variants match the `calendar.toml` schema in | enum InstrumentKind, enum Segment
- `crates/core/src/testutil.rs` - `FakeClock` and `fixture_path`, behind the `test-util` feature. | fn advance, fn at, fn fixture_path, fn set, struct FakeClock
- `crates/core/src/config/calendar.rs` - `calendar.toml` data types and validation. `MarketCalendar` (slice core-calendar) is built | enum AppliesTo, enum HolidayKind, enum Phase, enum SpecialKind, fn covers, struct CalendarConfig, struct HolidayRow, struct SessionRow, struct SpecialSessionRow
- `crates/core/src/config/error.rs` - Config errors. They carry the file name, a key path and a reason, never file contents, | enum ConfigError
- `crates/core/src/config/files.rs` - Typed structs for the six files that carry little or no data in F1. | const MAX_EVENTS, const MAX_SYMBOLS_PER_WATCHLIST, const MAX_TEXT_CHARS, const MAX_WATCHLISTS, enum EventKind, struct Event, struct EventsConfig, struct Watchlist, struct WatchlistsConfig
- `crates/core/src/config/mod.rs` - Config loading and typed config files, shared by cli, server and tests. | const MAX_CONFIG_BYTES, const SCHEMA_VERSION, enum StaleReason, fn load, fn parse_str, fn stale_warnings, struct Config, struct Header, struct StaleWarning, struct StalenessPolicy, trait ConfigFile
- `crates/core/src/config/risk.rs` - `risk.toml`: execution mode, owner limits and the hard ceilings the loader enforces. | struct ExecutionSection, struct HardLimits, struct Limits, struct ModeSection, struct RiskConfig

### crates/data - MarketData port adapters: Kite read-only client, bhavcopy, instrument master.
- `crates/data/src/lib.rs` - `MarketData` port adapters: Kite read-only client, bhavcopy, instrument master.

### crates/execution - Order pipeline, approval queue, Executor trait, kill switch and audit chain.
- `crates/execution/src/lib.rs` - Order pipeline, approval queue, `Executor` trait, kill switch and audit chain.

### crates/indicators - Pure indicator maths (streaming and batch); no I/O.
- `crates/indicators/src/lib.rs` - Pure indicator maths (streaming and batch); no I/O.

### crates/options - Pure options maths: pricing, Greeks, IV, payoff; no I/O.
- `crates/options/src/lib.rs` - Pure options maths: pricing, Greeks, IV, payoff; no I/O.

### crates/paper - PaperExecutor and PaperAccount (virtual rupee cash).
- `crates/paper/src/lib.rs` - `PaperExecutor` and `PaperAccount` (virtual rupee cash).

### crates/regime - Market regime detection (trend/range and volatility state).
- `crates/regime/src/lib.rs` - Market regime detection (trend/range and volatility state).

### crates/risk - Position sizing, portfolio limits and the DecisionGate.
- `crates/risk/src/lib.rs` - Position sizing, portfolio limits and the `DecisionGate`.

### crates/scanner - Runs strategies over the universe; scores, ranks and explains recommendations.
- `crates/scanner/src/lib.rs` - Runs strategies over the universe; scores, ranks and explains recommendations.

### crates/server - Composition root: axum REST on 127.0.0.1, security layer, OpenAPI, static UI.
- `crates/server/src/app.rs` - Router assembly (slice F1/server-app). | fn build
- `crates/server/src/error.rs` - problem+json error type and extractors (slice F1/server-security). | const PROBLEM_JSON, enum ApiError, fn code, fn from_status, fn problem, fn problem_backstop, fn status, fn unknown_api, struct ApiJson, struct ApiPath, struct ApiQuery, struct FieldError, struct Problem
- `crates/server/src/lib.rs` - Composition root: axum REST on `127.0.0.1`, security layer, `OpenAPI`, static UI. | mod app, mod dto, mod error, mod openapi, mod routes, mod security, mod state
- `crates/server/src/main.rs` - `bazaar-server` binary: `serve` (loopback only) and `openapi`.
- `crates/server/src/openapi.rs` - `OpenAPI` document, built from the same router that serves traffic (slice F1/server-app). | fn document, fn router
- `crates/server/src/security.rs` - Security layer: launch token, sessions, Host/Origin/CSRF guards, CSP (slice F1/server-security). | const CSP, const CSRF_HEADER, const EXEMPT_PATHS, const SESSION_COOKIE, enum SecurityError, fn auth, fn csrf_guard, fn ensure_loopback, fn host_guard, fn launch_url, fn loopback_addr, fn mint_kite_nonce, fn new, fn origin_guard, fn path_only_span, fn security_headers, fn session_guard, fn take_kite_nonce, struct AuthQuery, struct Security, struct Session
- `crates/server/src/state.rs` - `AppState` and its builder (slice F1/server-app). | fn new, struct AppState
- `crates/server/src/dto/mod.rs` - Response DTOs: wire shapes kept apart from domain types (slice F1/server-app). | enum ModeDto, struct AuthMeDto, struct StatusDto
- `crates/server/src/routes/auth.rs` - `GET /api/v1/auth/me`. | fn router
- `crates/server/src/routes/mod.rs` - Route handlers (slice F1/server-app). Handlers are thin; no route places an order. | fn api, mod auth, mod status
- `crates/server/src/routes/status.rs` - `GET /healthz` (public) and `GET /api/v1/status`. | fn healthz, fn router
- `crates/server/tests/app.rs` - Router-level contract tests (real layer stack, in-process, no socket).
- `crates/server/tests/common/mod.rs` - `TestApp`: the real router (`app::build`) run in-process with a fake clock and a temp web dir. | const HOST, const ORIGIN, const PORT, fn body_bytes, fn body_json, fn get, fn login, fn new, fn send, struct TestApp

### crates/store - SQLite and Parquet/DuckDB repositories implementing the core ports.
- `crates/store/src/lib.rs` - SQLite and Parquet/DuckDB repositories implementing the `core` ports.

### crates/strategies - Strategy trait and one module per strategy.
- `crates/strategies/src/lib.rs` - `Strategy` trait and one module per strategy.

### web/src/app
- `web/src/app/App.test.tsx`
- `web/src/app/App.tsx` | function App
- `web/src/app/AppShell.test.tsx`
- `web/src/app/AppShell.tsx` | function AppShell
- `web/src/app/Home.tsx` | function Home
- `web/src/app/ModeBadge.tsx` | function ModeBadge
- `web/src/app/SessionEnded.tsx` | function SessionEnded
- `web/src/app/SessionGate.test.tsx`
- `web/src/app/SessionGate.tsx` | function SessionGate
- `web/src/app/providers.tsx` | function Providers, function makeQueryClient
- `web/src/app/routes.tsx` | const routes

### web/src/shared
- `web/src/shared/disclaimer.ts` | const DISCLAIMER
- `web/src/shared/lib/format-inr.test.ts`
- `web/src/shared/lib/format-inr.ts` | function formatInr
- `web/src/shared/lib/format-ist.test.ts`
- `web/src/shared/lib/format-ist.ts` | const formatIst
- `web/src/shared/ui/Disclaimer.tsx` | function Disclaimer

### web/src/api
- `web/src/api/client.test.ts`
- `web/src/api/client.ts` | class ApiError, const CSRF_HEADER, const api, const onSessionEnded, const setCsrfToken, function unwrap, type Problem
- `web/src/api/keys.ts` | const keys
- `web/src/api/queries.ts` | const authMeQuery, const statusQuery
- `web/src/api/schema.d.ts` | interface components, interface operations, interface paths, type webhooks

## HTTP routes (axum; utoipa paths are relative to /api/v1)

- `/api/{*rest}` -> crates/server/src/app.rs:44
- `/auth/me` -> crates/server/src/routes/auth.rs:9
- `/auth` -> crates/server/src/app.rs:43
- `/auth` -> crates/server/src/security.rs:446
- `/echo` -> crates/server/src/error.rs:294
- `/healthz` -> crates/server/src/app.rs:42
- `/healthz` -> crates/server/src/security.rs:445
- `/item/{id}` -> crates/server/src/error.rs:440
- `/open` -> crates/server/src/security.rs:447
- `/status` -> crates/server/src/routes/status.rs:16
- `/x` -> crates/server/src/error.rs:471

## Config (rates and limits with verified_on)

- config/calendar.toml
- config/charges.toml
- config/compliance.toml
- config/data.toml
- config/events.toml
- config/risk.toml
- config/strategies.toml
- config/watchlists.toml

## Config keys (names from .env.example)

RUST_LOG, BAZAAR_PORT, BAZAAR_DATA_DIR, BAZAAR_CONFIG_DIR, KITE_API_KEY, KITE_API_SECRET, TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID

## Features (docs/features; details: just feature <id>)

- F1 Workspace bootstrap [building] - the repo builds, gates and serves: workspace + core types + config + a loopback-only axum server + a React shell with th

## In-flight (not merged into develop yet)

### feat/F1-core-calendar (last commit 57 minutes ago)
- changed crates/core/src/calendar.rs

### feat/F1-core-config (last commit 3 hours ago)
- deleted crates/core/src/config.rs
- added crates/core/src/config/calendar.rs
- added crates/core/src/config/error.rs
- added crates/core/src/config/files.rs
- added crates/core/src/config/mod.rs
- added crates/core/src/config/risk.rs

### feat/F1-core-types (last commit 4 hours ago)
- changed crates/core/src/clock.rs
- changed crates/core/src/disclaimer.rs
- changed crates/core/src/error.rs
- changed crates/core/src/money.rs
- changed crates/core/src/testutil.rs

### feat/F1-scaffold (last commit 4 hours ago)
- added crates/backtest/src/lib.rs
- added crates/broker/src/lib.rs
- added crates/cli/src/lib.rs
- added crates/cli/src/main.rs
- added crates/core/src/calendar.rs
- added crates/core/src/clock.rs
- added crates/core/src/config.rs
- added crates/core/src/disclaimer.rs
- added crates/core/src/error.rs
- added crates/core/src/lib.rs
- added crates/core/src/mode.rs
- added crates/core/src/money.rs
- added crates/core/src/segment.rs
- added crates/core/src/testutil.rs
- added crates/data/src/lib.rs

### feat/F1-server-security (last commit 3 hours ago)
- changed crates/server/src/error.rs
- changed crates/server/src/security.rs
- new routes: /auth, /echo, /healthz, /item/{id}, /open, /x

### feat/F1-server-startup (last commit 25 minutes ago)
- changed crates/server/src/main.rs

### feat/F1-server-wiring (last commit 43 minutes ago)
- changed crates/server/src/app.rs
- deleted crates/server/src/dto.rs
- added crates/server/src/dto/mod.rs
- changed crates/server/src/main.rs
- changed crates/server/src/openapi.rs
- deleted crates/server/src/routes.rs
- added crates/server/src/routes/auth.rs
- added crates/server/src/routes/mod.rs
- added crates/server/src/routes/status.rs
- changed crates/server/src/state.rs
- added crates/server/tests/app.rs
- added crates/server/tests/common/mod.rs
- new routes: /api/{*rest}, /auth, /auth/me, /healthz, /status

### feat/F1-web-client (last commit 27 minutes ago)
- added web/src/api/client.test.ts
- added web/src/api/client.ts
- added web/src/api/keys.ts
- added web/src/api/queries.ts
- added web/src/api/schema.d.ts
- changed web/src/app/AppShell.tsx
- added web/src/app/ModeBadge.tsx
- added web/src/app/SessionEnded.tsx
- added web/src/app/SessionGate.test.tsx
- added web/src/app/SessionGate.tsx
- changed web/src/mocks/handlers.ts

### feat/F1-web-scaffold (last commit 2 hours ago)
- added web/src/app/App.test.tsx
- added web/src/app/App.tsx
- added web/src/app/AppShell.test.tsx
- added web/src/app/AppShell.tsx
- added web/src/app/Home.tsx
- added web/src/app/providers.tsx
- added web/src/app/routes.tsx
- added web/src/main.tsx
- added web/src/mocks/browser.ts
- added web/src/mocks/handlers.ts
- added web/src/mocks/server.ts
- added web/src/shared/disclaimer.ts
- added web/src/shared/lib/format-inr.test.ts
- added web/src/shared/lib/format-inr.ts
- added web/src/shared/lib/format-ist.test.ts
