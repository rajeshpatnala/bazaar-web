# F1: Workspace bootstrap

Size: L   Estimate: ~3.0M tokens (agents ~2.7M + manager ~0.3M; range 2.4-3.6M)   Status: approved   Owner: tech-lead

## Owner decisions (2026-11-18, recorded)
- Full 10-slice plan approved; `per_task_tokens` raised to 4M; `tester_review = large` (team.md, synced). Lean option dropped.
- `risk.toml`: `execution_mode = "paper"`, 1% per trade, 3% daily loss, paper cash 100000, `source = "owner"`; `[hard_limits]` ceilings EQUAL these values.
- Toolchain: download Rust 1.100.0 via rustup and pin it in `rust-toolchain.toml` (no fallback to 1.99.1).
- Dependency list in Design notes approved as written (new deps beyond it need a fresh approval).
- F2 (fill `calendar.toml`/`charges.toml` from official NSE/Zerodha sources) queued for later, not part of F1.

## Next step (manager): dispatch batch 1 = slice 0 only
dev-core, `feat/F1-scaffold`, Plan: this file (slice 0), Verify T0+T1. Start `just budget-task F1`; tester may start the T2 test plan in parallel.
Wave 1 (slices 1, 2, 4, 5) is dispatched only after slice 0 is merged.

## Goal
Turn the empty repo into a working Bazaar workspace: Cargo workspace with the 14-crate map, the eight `config/*.toml` files
(headers with `source`/`verified_on`), core types (Money/Price/Qty over `Decimal`, IST `Clock`, `MarketCalendar`), an axum
server on 127.0.0.1 only (`/healthz`, launch-token session, Host/Origin/CSRF/CSP guards, problem+json, utoipa OpenAPI), a
`web/` React 19 + Vite + TS app on generated API types with the permanent disclaimer, and a green `just gate`.
No CI workflow (owner adds later), no data stores, no Kite, no WebSocket, no charts, no order path.

## Acceptance criteria
1. Given a clean checkout, when `just gate` runs, then fmt, clippy `-D warnings`, nextest, web typecheck/lint/vitest all pass.
2. Given `cargo metadata`, then every crate edge is within the `bz-architecture` s2 table, no domain crate depends on `bazaar-server`,
   and `live-trading` is in no `default` feature and no `--all-features` recipe.
3. Given `config/`, then it holds exactly the eight files, each with `schema_version`, `verified_on`, `source`; every loader rejects
   unknown keys and TOML floats for money; `risk.toml` has `execution_mode = "paper"` and a `[hard_limits]` ceiling the loader enforces.
4. Given the fixture calendar, when asked about weekend/holiday/special session/out-of-range year/expiry shift/session boundary, then
   `MarketCalendar` answers per `bz-repo-structure` s5 with no hour or date literal in non-test source (Sat/Sun weekend is the only structural weekday fact; amended 2026-11-19, CR-21-1).
5. Given `bazaar-server` started with test fakes, then it binds only a loopback address (a non-loopback address is refused) and
   `/healthz` answers without a session.
6. Given no session cookie, when any `/api/v1/**` route is called, then 401 problem+json; wrong Host -> 403 `forbidden_host`; non-GET with
   wrong/missing Origin -> 403 `forbidden_origin`; non-GET without CSRF -> 403 `csrf_invalid`; unknown `/api/*` -> 404 problem+json.
7. Given the launch URL, when `/auth?token=` is called, then 303 + `bz_session` (HttpOnly, SameSite=Strict); a second use, a wrong
   token or an expired token -> 403 `launch_token_invalid` and a wrong guess does not consume the token.
8. Given `bazaar-server openapi`, then the JSON parses, every path starts `/api/v1/`, money-typed schemas are `string`, and
   `just openapi` regenerates `web/src/api/schema.d.ts` with no diff.
9. Given the UI at any route and in API-error state, then the exact disclaimer (from `bz-india-markets` compliance reference) is visible in
   `role="contentinfo"`, not dismissible, in normal flow (no `position: sticky|fixed`), and the shell fits 1280x720 and 1024x600 without
   page scroll (owner rules). The Rust constant and the TS constant are byte-equal (tested).
10. Given a 401 from `/api/v1/auth/me`, then the UI shows the session-ended screen (no form, no retry loop, disclaimer still shown);
    given 200, the shell shows the PAPER badge in text + colour from `mode`.

## Out of scope
SQLite/DuckDB/Parquet, sqlx migrations, Keychain `SecretStore`, Kite, bhavcopy, WebSocket hub, charts, scheduler, real calendar/charges
data (see risks), CI workflow, `bazaar-cli` subcommands (stub binary only), release-please wiring, Playwright e2e.

## Design notes
- No architect needed: crate map, security template and API shape are fixed by the skills. Deviations go to `.agents/decisions.md`.
- Server F1 surface: `GET /healthz`, `GET /auth`, `GET /api/v1/auth/me` (`AuthMeDto`), `GET /api/v1/status` (subset `StatusDto`:
  `server_time`, `version`, `mode`, `live_enabled`; later features add fields, additive only), `/api/{*rest}` 404, static `web/dist` + SPA fallback.
  `live_enabled = cfg!(feature = "live-trading")`; `mode` read from `risk.toml [mode]` via `bazaar_core::config`.
- Contracts frozen in slice 0 (so later slices never touch the same file): root `[workspace.dependencies]` (all F1 externals), every
  member `Cargo.toml`, `core/src/lib.rs` module list, `server/src/lib.rs` module list (empty stub files), `Clock` trait, `ExecutionMode`,
  `Segment`/`InstrumentKind` enums. Slices fill their own files only.
- Server skeleton has no SQLite/Keychain/Kite: `AppState { clock, mode, security, web_dist }` built by `build_state(..)`; tests use fakes.
- Skills cite `CONTRACTS.md`, which is not in the repo. The code sketches in `bz-security` / `bz-web-api` are the authority; the CSP string is
  a constant with a snapshot test.
- Config key lists: `risk.toml` only `[mode]`, `[limits] max_risk_per_trade_pct/max_daily_loss_pct`, `[hard_limits]` ceilings for those two,
  `[execution] paper_starting_cash_inr` (owner profile, `source = "owner"`). The other six files carry the header plus empty tables
  (typed header-only structs that later features replace); `watchlists.toml` has the `[[watchlist]]` shape. No market fact is typed from memory.
- Dependency set for owner approval: Rust: tokio, tokio-util, rust_decimal, chrono, chrono-tz, serde, serde_json, toml, thiserror, anyhow, tracing,
  tracing-subscriber, clap, dotenvy, axum, axum-extra, tower, tower-http (no `cors`), utoipa, utoipa-axum, subtle, getrandom, http-body-util,
  proptest, insta. Web: react, react-dom, react-router, @tanstack/react-query, openapi-fetch, openapi-typescript, vite, @vitejs/plugin-react,
  typescript ~6.0, vitest + coverage-v8, jsdom, Testing Library, msw, eslint + typescript-eslint, prettier. Deferred: sqlx, duckdb, polars,
  reqwest, keyring, secrecy, tokio-tungstenite, lightweight-charts, zustand, playwright, criterion, wiremock.

## Slices
Line limit 400 per slice excludes lock files and generated `schema.d.ts`. Every slice: unit tests, `Verify: T0+T1`, never T2.
Branch `feat/F1-<slug>`; PR title `feat(<area>): ...` with `Refs: F1`. Developers hand the tech lead one "record line" each; only slices 0 and 9 edit the feature record.

| # | agent | branch slug | files owned | depends on | T1 (one look) |
|---|---|---|---|---|---|
| 0 | dev-core | scaffold | root `Cargo.toml`, `rust-toolchain.toml`, `rustfmt.toml`, `clippy.toml` (bans wall-clock), `.editorconfig`, `.env.example` (reconcile existing), `.gitignore` check, 14 crate manifests + stub `lib.rs`/`main.rs` (cli, server), `core/src/{lib,clock(trait only),segment,mode}.rs`, `server/src/lib.rs` + empty module stubs, `justfile` Bazaar recipes below the kit block, `docs/features/F1-*.md` (Status: building) | - | `just gate` green; `just --list`; `cargo metadata` shows 14 packages |
| 1 | dev-core | core-types | `core/src/{money,clock,error,disclaimer,testutil}.rs` (Money/Price/Qty/Lots, rounding policy, `SystemClock`, `FakeClock` + `fixture_path` behind `test-util`, `DomainError`, `DISCLAIMER`) | 0 | one reference-value money test |
| 2 | dev-core | core-config | `core/src/config/**` (Header, `ConfigFile`, `load`, `ConfigError`, staleness, 8 typed structs, `RiskConfig` + hard-ceiling check, CalendarConfig data types), `config/*.toml` (8), `fixtures/config/*.toml` (8 twins, synthetic, with `fixtures/README.md`) | 0 | loader loads shipped `config/` and `fixtures/config/` |
| 3 | dev-core (same dev as 2) | core-calendar | `core/src/calendar.rs` (`MarketCalendar`, `Session`, `CalendarError`), calendar tests, any extra rows in `fixtures/config/calendar.toml` | 2 | fixture holiday-expiry shift test |
| 4 | dev-ui | web-scaffold | `web/**` except `src/api/**`: package.json, lockfile, `.nvmrc`, tsconfig, vite (proxy), vitest, eslint, prettier, `index.html`, `app/` (AppShell, router, providers), `shared/{disclaimer.ts,ui/Disclaimer,lib/format-inr,format-ist}`, `mocks/` + `test/` infra, layout CSS | 0 | screenshot via `just app-dev` at 1280x720 and 1024x600 |
| 5 | dev-api | server-security | `server/src/{security,error}.rs` + unit tests (guards, token single-use/TTL, cookie flags, CSP snapshot, loopback guard, problem+json backstop, ApiJson extractors) | 0 | one oneshot 401 + one 403 host test |
| 6 | dev-api (same dev as 5) | server-app | `server/src/{app,state,openapi}.rs`, `routes/**`, `dto/**`, minimal `main.rs` (clap + `openapi` subcommand), `server/tests/**` (TestApp harness, auth/status/healthz/static/openapi contract tests) | 5, 1 (FakeClock) | oneshot `/api/v1/auth/me` after `/auth` exchange |
| 7 | dev-api (same dev) | server-startup | `server/src/main.rs` (config load, tracing, loopback bind + assert, launch URL via `writeln!`, `open` best effort, graceful shutdown), `deny.toml` reconcile (`cargo deny check` green) | 6, 2 | bind-address fn test + `bazaar-server openapi` parses |
| 8 | dev-ui (same dev as 4) | web-client | `web/src/api/**` (generated `schema.d.ts`, `client.ts`, keys), `app/SessionGate`, session-ended screen, `ModeBadge`, `queries` for auth/status, `mocks/handlers.ts` typed from schema, tests | 4, 6 | screenshot: shell with PAPER badge; session-ended screen |
| 9 | dev-core (continue slice 0 dev) | workspace-checks | `crates/cli/tests/{architecture,workspace}.rs` (edges from `cargo metadata`; `live-trading` not default; `.env.example` empty values and no mode var; server/web versions equal; config has exactly 8 files; Rust vs TS `DISCLAIMER` equal), `README.md` (disclaimer on top, prerequisites, `just setup/run/app-dev`), feature record -> `Status: done` with What was built | 1-3, 7, 8 | the new tests |

Order / parallelism (worktrees): slice 0 merges first (alone). Then four in parallel: **1, 2, 4, 5**. Then **3** (after 2) and **6** (after 5 and 1).
Then **7** (after 6 and 2) in parallel with **8** (after 4 and 6). Then **9**. Merge small and foundational first (0, 1, 2, 5, 4, 3, 6, 7, 8, 9);
later branches rebase. Slices 5-7 (and 2-3, 4-8) are the same developer continued, so each pair costs one cold start.
Peak 4 developers. Agents to budget-check: `dev-core:3 dev-ui:1 dev-api:1`.

## Reviews (per `just review-plan`; this is the expected set)
- code-reviewer: every PR (10).
- security-reviewer: 0 (deps), 2 (config), 4 (deps), 5, 6, 7 (auth, Host/Origin/CSRF/CSP, bind); 8 only if >150 lines of CSRF/401 middleware.
- quant-reviewer: 1 (Money rounding, Decimal serde), 3 (calendar, market facts out of source).
- risk-guardian: 0 (`live-trading` not default), 2 (`risk.toml`, mode, hard ceilings). Blockers treated like code-review blockers.
- market-strategist: not needed (no strategy, recommendation, risk-rule or options content).
- tester: T2 test plan written in parallel with wave 1; ONE T2 run after slice 9 (gate + `just check`, OpenAPI drift, negative auth cases on
  every route, disclaimer on every route incl. API-down, screenshots at 1280x720/1024x600, no-sticky grep, loopback refusal, the "not verified" list).
  merge-check wants tester sign-off per feat PR: recommend `tester_review = large` for F1 so only slices > `large_pr_lines` get a separate sign-off;
  T2 sign-off goes on the last PR.

## Estimate (tokens; typical, not caps)
| item | runs | tokens |
|---|---|---|
| dev-core: 0 150k, 1 90k, 2 130k, 3 70k (cont.), 9 70k (cont.) | 3 devs | 510k |
| dev-ui: 4 180k, 8 100k (cont.) | 1 dev | 280k |
| dev-api: 5 140k, 6 110k, 7 80k (cont.) | 1 dev | 330k |
| fix rounds (avg 1 per PR, continued devs) | 10 | 250k |
| code-reviewer 10 x 45k | 10 | 450k |
| security-reviewer 6 x 40k | 6 | 240k |
| quant-reviewer 2 x 45k, risk-guardian 2 x 40k | 4 | 170k |
| tester: test plan 50k + T2 200k + sign-offs ~50k | 3 | 300k |
| tech-lead triage + merges, build-runner | - | 210k |
| **agents subtotal** | | **~2.74M** |
| manager (~10%) | | ~0.3M |
| **total** | | **~3.0M** (limit 3.0M: expect WARN/OVER, ask owner) |

Why not smaller: ten PRs is the cost of 400-line slices over ~3,000 lines of code + tests + 14 crates; a bootstrap has no cheaper shape
without exceeding the slice limit. **Lean option (needs owner OK to exceed 400 lines/slice):** merge 1+2+3 into one core PR and 5+6+7 into
one server PR: 6 PRs, ~2.4M, but larger reviews and less parallelism.

## Feature record (draft; slice 0 commits it as docs/features/F1-workspace-bootstrap.md)
```
# F1 - Workspace bootstrap
Status: building
Summary: the repo builds, gates and serves: workspace + core types + config + a loopback-only axum server + a React shell with the disclaimer.
Owner area: Cargo.toml, crates/{core,server,cli,...stubs}, config/, fixtures/config/, web/, justfile
## Acceptance criteria  (copy the ten above, shortened)
## What was built  (slice 9 fills: routes, config files, crates, scripts, key names; config keys: none env-driven except BAZAAR_PORT/BAZAAR_CONFIG_DIR/BAZAAR_DATA_DIR)
## Decisions  toolchain pin; additive StatusDto subset; header-only config structs; synthetic fixtures; no CORS; disclaimer constant duplicated Rust/TS with equality test
## Known limits  calendar.toml/charges.toml hold no market data yet; no WebSocket; server has no store; cli is a stub; no CI workflow
## Deferred  (triage fills)
```

## Security notes
Trust boundary: the owner's browser vs a hostile page (DNS rebinding, CSRF, cross-origin). Launch token: 32 random bytes, single use, 600 s,
constant-time compare, printed once with `writeln!` to stdout (never `tracing`), never in logs (trace span uses path only). Cookie HttpOnly,
SameSite=Strict. No CORS layer. Bind constant `127.0.0.1`, no address flag, `local_addr` asserted loopback. Tests never use port 8787, never
touch `.env`, Keychain, `data/`. `.env.example` has names with empty values only.

## Risks / open questions
- Toolchain: skills pin Rust 1.100.0; local rustc is 1.99.1. Slice 0 tries `rust-toolchain.toml` 1.100.0 (rustup download); if offline it pins 1.99.1 and logs it in `decisions.md`.
- Crate/npm versions in the skills are research snapshots; a version that fails to resolve or compile (`axum-extra` cookie API, utoipa `decimal`, TS `~6.0` vs
  openapi-typescript peer) is reported to me, not silently changed; deliberate changes go to `decisions.md`.
- `CONTRACTS.md` is referenced by many skills but absent; tracked as a kit issue for the manager.
- `calendar.toml`/`charges.toml` real data (holidays, session windows, STT/brokerage) must come from official sources with `verified_on`: proposed as follow-up F2, not F1.
- Slice 0 is the largest foundation and the one merge everything waits on; if it passes 400 lines the developer moves the README stub and justfile extras into slice 9.
- Existing `.env`/`.env.example`/`.github/` are not touched except reconciling `.env.example` key names (agents never read `.env`).
