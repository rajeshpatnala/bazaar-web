# F2: Market data foundation (offline reference data)

Size: L   Estimate: ~2.1M tokens (agents ~1.8M + manager ~0.3M; range 1.7-2.6M)   Status: draft   Owner: tech-lead

## Goal
Give the app its reference data, with no network and no secrets: real `calendar.toml` and `charges.toml` (sourced, dated), a
typed charges loader, the instrument master (parse, validate, store, query) from a file, and the calendar edge tests deferred
from F1. Everything is built and tested against synthetic fixtures; real market values enter only as owner-supplied data
(slices 6, 7). Kite login/fetch, bhavcopy, candles (Parquet/DuckDB), WebSocket and `data.toml` values are **F3** (needs the
owner's Kite account and a human-run first fetch).

## Acceptance criteria
1. Given the real `config/calendar.toml`, when loaded, then it is not `placeholder`, carries `verified_on` and a per-row `source`, covers
   the stated years, and `MarketCalendar` answers from it (holidays, sessions, special sessions) with no market literal in source.
2. Given `config/charges.toml`, when loaded, then every `[[rate_set]]` is effective-dated with `verified_on` + `source`, rates are `Decimal`
   from strings (a TOML float is rejected), unknown keys, duplicate (exchange, segment, side, effective_from) and missing `source` are load errors;
   a lookup with no rate set in force returns an error, never a fallback.
3. Given a fixture Kite-format instruments CSV, when parsed, then `Instrument` has `Decimal` tick/strike, `NaiveDate` expiry, an `Other(_)`
   fallback for unknown types, tolerates extra columns, fails with a clear error on a missing required column, and bad rows (non-positive
   tick/lot, malformed numbers) are rejected and counted in a `CleaningReport`; truncated or oversize input never panics.
4. Given the instrument master, then "next expiry of an underlying" and "F&O eligible (cash_fno)" are functions over the data; a test that
   moves the fixture expiry weekday shows the code follows it.
5. Given an in-memory/temp SQLite, when the same file is imported twice, then rows are identical (idempotent upsert on `(exchange, tradingsymbol)`),
   a dated snapshot is kept, `fetched_on` is recorded, migrations run on an empty DB, and Decimal values round-trip exactly.
6. Given `bazaar-cli check-connections --config-dir fixtures/config --data-dir <tmp>`, then it prints `OK sqlite` and `OK|FAILED instruments <category>`
   (freshness vs the calendar's last trading day); `import-instruments --file <csv>` loads a fixture file. No network, no secret read.
7. Given the calendar deferred items, then TS-21-1..4, TS-21-6 and CR-21-3 (F1 record, *Deferred*) are done.

## Out of scope (-> F3 unless noted)
Kite login/fetch/historical/WebSocket, `data.toml` values and rate limits, bhavcopy and Parquet/DuckDB candles, corporate actions, ban list and
price bands, `events.toml` data, `CostModel` computation and contract-note cross-check (backtest feature), BSE/currency/commodity charges.

## Design notes
- Types (`Instrument`, `InstrumentType`, `Exchange`, `CleaningReport`) and the `InstrumentRepo` port go in `core` (slice 0); the parser in `data`,
  SQLite in `store`; `data` and `store` depend only on `core` (architecture table); only `cli` wires them.
- `core::segment::InstrumentKind` (4 kinds) stays as is; the master supplies `cash_fno` eligibility (a stock has a derivative in the master) to
  `MarketCalendar::session_at`. No segment/hours literal in `data`.
- Charges: typed structs replace the header-only `ChargesConfig` in `core/src/config/files.rs`; schema is `bz-backtest-risk` `charges-toml` s1
  (the only copy). Computation (CostModel) is NOT in F2, so no rounding policy decision yet.
- Parser reads `&[u8]`/`impl Read` (caller supplies bytes); bounds: max bytes, max rows, max field length. Gzip and HTTP arrive with F3.
- SQLite via sqlx 0.9 (runtime queries with explicit columns, no `SELECT *`), money as canonical `TEXT`, dates `YYYY-MM-DD` IST, forward-only migrations in
  `crates/store/migrations/`, one writer pool; `ping()` + `safe_reason()` categories only (`bz-market-data` s8, `storage.md`).
- Placeholder rule: a file with `placeholder = true` stays valid and never reads as fresh; slices 6/7 flip it only with owner-confirmed data.
- New workspace deps (need owner OK, Q4): `sqlx` (sqlite, migrate, runtime-tokio), `csv`, `sha2` (import file hash), dev `tempfile`. Versions only in root `Cargo.toml`.

## Slices
Line limit 400 per slice (toml data and lock files excluded). Every slice: unit tests, `Verify: T0+T1`, never T2. Branch `feat/F2-<slug>`, PR `feat(<area>): ...` with `Refs: F2`.
Only slice 0 commits the feature record; slice 7 fills "What was built". Developers hand the tech lead one record line each.

| # | agent | slug | files owned | depends on | order |
|---|---|---|---|---|---|
| 0 | dev-core (A) | ref-contracts | `core/src/{instrument,ports}.rs`, `core/src/lib.rs` (2 mods), root `Cargo.toml` (deps), `crates/{data,store,cli}/Cargo.toml`, `docs/features/F2-*.md` | Q4 | 1 |
| 1 | dev-core (A, continued) | calendar-edges | `core/src/calendar.rs` (CR-21-3 comment + tests), `core/tests/calendar_edges.rs` (proptest + edges, TS-21-1..4, 6) | - | 1 (after 0, same dev) |
| 2 | dev-backtest | charges-config | `core/src/config/{charges.rs,files.rs,mod.rs}`, `fixtures/config/charges.toml` (synthetic rate sets), `core/tests/charges_config.rs`; `config/charges.toml` stays placeholder | Q3 | 1 (parallel with 0) |
| 3 | dev-data (B) | instrument-master | `data/src/{lib,instruments/**}.rs`, `fixtures/data/instruments_*.csv` (good, extra-column, bad-rows, truncated), tests | 0 | 2 (parallel with 4) |
| 4 | dev-data (C) | store-sqlite | `store/src/**`, `store/migrations/**`, store tests | 0 | 2 (parallel with 3) |
| 5 | dev-data (C, continued) | cli-import | `cli/src/**`, `cli/tests/**` (`import-instruments --file`, `check-connections` sqlite + instruments) | 3, 4 | 3 |
| 6 | dev-data (B, continued) | calendar-data | `config/calendar.toml`, `core/tests/real_calendar.rs`, `docs/owner-input/F2-calendar.md` (the owner's source) | 1, **Q1 owner input** | 3 |
| 7 | dev-data (B, continued) | charges-data | `config/charges.toml`, `core/tests/real_charges.rs`, F2 record "What was built" | 2, **Q2 owner input** | 4 |

Parallelism (worktrees): wave 1 = slice 0 then 1 (dev A) alongside slice 2 (dev-backtest); wave 2 = 3 and 4 in parallel after 0 merges (each > 150
production lines, repays a second cold start); wave 3 = 5, plus 6 and 7 as soon as the owner input lands (they may run earlier, in any order after
their deps). Peak 3 developers. Budget check: `dev-core:1 dev-backtest:1 dev-data:2` (B and C; slices 5-7 continue them).
Lean option: drop slice 5 (CLI) to F3 (saves ~200k); then `check-connections` arrives with the Kite session.

## Reviews (expected from `just review-plan`)
- code-reviewer: every PR (8). security-reviewer: 0 (deps), 3 (untrusted bytes), 4 (SQL, paths), 5 (file path input).
- quant-reviewer: 1, 2, 3, 6, 7 (calendar, charges, tick/lot/expiry facts out of source; auto-added by path). risk-guardian: none expected. market-strategist: not needed.
- tester: write the T2 test plan in parallel with wave 1; ONE T2 run after the last slice (gate, `just check`, `cli check-connections` on fixtures, idempotent import twice,
  malformed/truncated/oversize CSV, real calendar/charges load with `verified_on` and sources, no network access, "not verified" list).

## Feature record (draft; slice 0 commits `docs/features/F2-market-data-foundation.md`)
Status: building. Summary: reference data foundation: real calendar and charges data, typed charges loader, instrument master parse + SQLite store + CLI import.
Owner area: `config/{calendar,charges}.toml`, `crates/{data,store}`, `core/src/{instrument,ports}.rs`, `core/src/config/charges.rs`, `fixtures/data/`, `cli`.
Acceptance criteria = section above. Decisions: offline F2 / network F3 (Q3); deps (Q4); owner supplies calendar and charges sources (Q1, Q2).
Known limits: no live data, no Kite, no candles, no CostModel, no BSE/currency/commodity charges; real data is only as fresh as its `verified_on`.
Deferred: TS-21-1..4, 6 and CR-21-3 move to done in slice 1 (remove from F1's list in the slice-0 record edit).

## Test plan
`F2-tests.md` (written by the tester).

## Security notes
Untrusted CSV bytes: bounded size/rows/fields, no panic, no path from CSV used on disk. SQLite: parameterised queries, no string-built SQL, no paths or file
contents in errors. No secrets, no network, no `.env` read in F2. Import takes a user file path only from the CLI argument and never follows it into logs.

## Risks / open questions
- Calendar and charges numbers cannot come from agents or memory: slices 6/7 are blocked on the owner input (Q1, Q2); until then both files stay `placeholder` and F2 can
  merge everything else. If the owner input is late, F2 closes with 6/7 deferred and the files still placeholder (recorded in Known limits).   
  A) We can use BSE calendar, it contains holidays, special trading sessions too, and about charges, we can check with zerodha, may be via API or i ll provide them later (for now you can put some dummy charges, if it is blocking)
- Kite column names/format are from the docs read 2026-11-18 and may change (UDiFF); parser is tolerant of extra columns and fails on a missing one.
   A) we ll figure it later
- sqlx 0.9 API differs from 0.8: the developer checks the changelog before writing queries.
   A) understood
- Charges sources can disagree (GST base, DP charge, IPFT); the broker page and a contract note win, recorded in `.agents/decisions.md` (done in slice 7).
   A) i need to review the broker charges, make it configurable, so its each for every one to change later
