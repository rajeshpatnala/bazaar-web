# Code review: project-settings (PR 8, chore/f1-budget-settings -> develop)

Verdict: APPROVE WITH MINORS

Scope: .agents/team.md (per_task_tokens 3,000,000 -> 4,000,000; tester_review behaviour-change -> large), .agents/decisions.md (+1 row). 5 lines, no production code, red-flag scan clean, no secrets.

Consistency: `large` is a documented tester_review value (team.md line 134). per_task_tokens 4,000,000 is below per_day_tokens 15,000,000. No conflict with CLAUDE.md. Pack labels the feature F1; reviewed under requested id project-settings.

## Findings

- CR-project-settings-1 | minor | .agents/decisions.md:7 | Status: open
  Issue: the row contains `1%% / 3%%` (shell printf escaping leaked). Should be `1% / 3%`.
  Fix: replace `%%` with `%` in that row.
- CR-project-settings-2 | nit | .agents/decisions.md:7 | Status: open
  The row records Rust pin and risk ceilings but not the budget/tester_review change in this PR. Optionally add it, or leave to team.md history.
