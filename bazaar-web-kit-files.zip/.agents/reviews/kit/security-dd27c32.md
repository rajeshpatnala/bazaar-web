# Security review: PR #9, commit dd27c32 (verdict: BLOCK)

Recorded by the manager from the security-reviewer hand-back (the reviewer's own file was not written).
Counts: 0 critical, 1 high, 0 medium, 1 low, 1 info.

## SEC-kit-10 (HIGH, blocker)
`diff_stats` parses `git diff --numstat`. Git prints renames as `{docs => .claude/agents}/a.md` (reproduced in a scratch repo).
That path misses LIGHT_EXCLUDE and the sensitive globs, but `**/*.md` still matches it. A rename of docs/*.md into
`.claude/`, `CLAUDE.md` or `.agents/team.md` therefore gets the light lane with no review.
Fix: add `--no-renames` to the numstat call, plus a smoke case.

## SEC-kit-11 (low)
`merge <pr>` and `merge-check` don't validate the PR argument (only `ship` does): gh option injection, not command
execution. `isdigit()` also accepts Unicode digits (use `isascii() and isdigit()`).

## SEC-kit-12 (info)
The leading-dash branch check exists only in `merge()`. Other paths reach only read-only git commands.

## Verified OK
`--` plus the dash check on `git merge` / `branch -D`; no `shell=True` on user input; list argv throughout; glob regexes
anchored and escaped; invalid `light_lane` fails closed; `ship` pull failure returns 1; kit-smoke.sh writes only under
mktemp (minor: fixed log path /tmp/kit-smoke.log).

## Re-check of 71ccd9a (status table)
| Id | Status | Note |
|---|---|---|
| SEC-kit-10 | fixed | `--no-renames` on every path-based diff feeding lane/review/test decisions: `diff_stats` numstat, `test_check` name-only (x2), codemap name-status. Smoke case 4b covers rename into `.claude/`. `.agents/templates/**` and `.agents/project.md` added to LIGHT_EXCLUDE. |
| SEC-kit-11 | fixed | `check_pr_arg` (ASCII digits) is called inside `pr_info`, which every PR path (review-plan, merge-check, merge, promote) reaches before any `gh` call; `wait_ci` in merge-check and `ship` are guarded too. No path reaches `gh` with an unvalidated PR arg. |
| SEC-kit-12 | fixed (was deferred) | `head_branch` (leading dash rejected, `rev-parse --verify -q refs/heads/<name>`, list argv, no shell) now guards review-plan, merge-check and merge. `opt_value` turns a missing value into a clean exit; `--branch --title` is rejected by the dash check. |
| SEC-kit-13 (info, new) | open, no block | `git diff -U3` for the red-flag scan (review-pack) and the `test_check` patch lack `--no-renames`. These scan content, not lane decisions; a pure rename shows no hunks so moved files are not red-flag scanned. Add `--no-renames` for completeness. |
