# Code review: kit (PR #9, chore/kit-0.2.0 -> develop)

Verdict: APPROVE WITH MINORS
Scope: kit.py (+179), justfile, hook, skill/agent text. Installer output. py_compile passes. No production code.

## Findings

| id | severity | where | status |
|---|---|---|---|
| CR-kit-1 | major (security) | kit.py LIGHT_GLOBS / required_reviews | fix now (TL: add LIGHT_EXCLUDE, see below) |
| CR-kit-2 | minor | .agents/team.md:133 | fix now (move row into table; kit source team template) |
| CR-kit-3 | minor | kit.py required_reviews | fix now (validate against {skip,quick,off}, else off) |
| CR-kit-4 | minor | kit.py find_review | defer: kit backlog (same as SEC-kit-2; header/SHA binding) |
| CR-kit-5 | minor | kit.py preflight (+5 lines) | reject: warning only, correct for worktree mode |
| CR-kit-6 | nit | kit.py ship | fix now (return 1 when pull fails; merge already done) |

**CR-kit-1 (major, `security`)**: `LIGHT_GLOBS` includes `**/*.md` and `*.md`, and the default `light_lane = skip` means no review at all. Agent prompts (`.claude/agents/*.md`), skills (`.claude/skills/**/SKILL.md`), `CLAUDE.md` and `.agents/owner-rules.md` are all markdown, and they set agent behaviour and guardrails (for example "never merge", "no secrets"). A PR that only edits those would merge with zero review, including from a dev agent. Fix: exclude `.claude/**` and `CLAUDE.md` from the light lane, or default to `quick`. Only the light-lane globs need to change.

**CR-kit-2 (minor)**: the `| light_lane | skip |` row was added after a blank line, outside the settings table. The regex in `team_setting` still finds it, so it works, but it renders as stray text. Move it into the table above.

**CR-kit-3 (minor)**: any `light_lane` value other than `off`/`quick` (a typo such as `Skp`) silently acts as `skip`. Validate against `{skip, quick, off}` and fall back to `off`, the safe choice.

**CR-kit-4 (minor)**: the `find_review` fallback accepts any review file whose first 15 lines mention the branch or PR number. It is not tied to the head commit, so a stale APPROVE from an earlier head can satisfy the check. This is acceptable given the findings template, but note it.

**CR-kit-5 (minor)**: preflight now reports a problem when the main checkout is not on the integration branch and more than one worktree exists. This is correct for worktree mode but will flag the user's normal state, for example while on this very branch. It is a warning only, so I raised no blocker.

**CR-kit-6 (nit)**: `ship` runs `git switch` and `git pull --ff-only` in the main checkout after the merge. Failures are reported ("not updated") but still return 0. That is fine, but the exit code does not reflect a stale local integration branch.

## Checked, OK
- Merge paths: `ship <pr>` only waits and then calls the existing `merge()`, which runs the merge-check first. A wait timeout or pending CI makes the merge-check fail, so nothing merges unchecked. There is no new `--delete-branch` path, and protected branches are still excluded.
- `ship --branch` delegates to the unchanged local merge, which keeps the title and gate checks.
- `status` is read-only. The `gh pr list` and merge-check calls are wrapped, and `SystemExit` is caught per PR. The subprocess calls use list args (no shell) with captured output.
- `wait_ci` polls with a grace period, a timeout (default 1200s) and a 15s sleep, so there is no unbounded loop. `ci_pending` treats missing checks as pending only until the grace period ends.
- Hook `dev-git-guard.sh` now denies `just ship`, matching `merge`. The `justfile` recipes are consistent with the kit.py usage text. `just review-plan --files a,b` works because the `pr` positional absorbs `--files`, as with `--diff`.
- Docs match the code: CLAUDE.md, git-workflow, tech-lead, manager and AGENT-SETTINGS agree on `ship`, `--wait`, `--files` and `light_lane`.
- Red-flag hit (tech-lead.md:59) is prose naming `just ship`, not a defect.
- Not run: the unit tests and gate. This PR has no production code, and kit.py has no test suite in the repo.

## Tech-lead decisions (round 1)
- CR-kit-1 / SEC-kit-1: add `LIGHT_EXCLUDE = [".claude/**", "CLAUDE.md", "**/CLAUDE.md", ".agents/owner-rules.md", ".agents/team.md", ".agents/scripts/**", ".github/**"]`; light lane applies only if every path matches LIGHT_GLOBS and none matches LIGHT_EXCLUDE. Keep default `skip` (remaining paths are docs/records). Reason shown: "light lane: only docs/records".
- CR-kit-3: `light = team_setting(...).strip().lower(); if light not in {"skip","quick","off"}: light = "off"` (print a one-line warning).
- CR-kit-6: ship prints "merged; <integ> not updated (...)" and `return 1` when switch/pull fails; `return 0` otherwise.
- dd27c32 (hardening): APPROVE WITH MINORS (CR-kit-7..10 minor/nit; CR-kit-1/3/6 and SEC-kit-1 fixes verified) - see code-review-dd27c32.md
- 71ccd9a re-check: APPROVE (CR-kit-7..10 fixed; opt_value/head_branch/check_pr_arg correct, callers review_plan/merge_check/merge/promote/ship unaffected)
