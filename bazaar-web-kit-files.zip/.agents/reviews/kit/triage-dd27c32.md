# Triage: kit, PR #9 (chore/kit-0.2.0), commit dd27c32

Tech lead decisions. One fix round, one push. Scope: kit tooling only (no app code).
Note: `security-dd27c32.md` is not on disk (only `security.md`, round 1). SEC-kit-10..12 are triaged from the manager's summary; SEC-kit-11/12 need the text confirmed (see below).

| id | sev | decision | why |
|---|---|---|---|
| SEC-kit-10 | high | **fix now (blocker)** | `diff_stats` uses `git diff --numstat` with rename detection, so a rename shows as `old => new` / `{a => b}`. A move out of `.claude/` or `.agents/team.md` into `docs/*.md` is matched on the wrong string and takes the light lane (no review). Weakens a review guard. |
| SEC-kit-11 | low | fix now if the reviewer's fix is <= a few lines in kit.py/SKILL.md/smoke; otherwise `defer: kit backlog` | text not available to me; same file set and the round is open anyway, so a cheap fix costs nothing extra. Developer decides on size and states it in the handoff. |
| SEC-kit-12 | info | defer: kit backlog (no action) | info only, no behaviour change required. |
| CR-kit-7 | minor | fix now | `--branch`/`--title` as last arg gives a traceback; add bounds check + `sys.exit("kit: --branch needs a value")`, and verify `head` exists (`git rev-parse --verify -q refs/heads/<head>`) before `merge_check`. |
| CR-kit-8 | minor | fix now | one sentence in `delivery-process/SKILL.md` (§3 step 9 or §10): `ship` exit 1 with "merged; <integ> not updated" means merged, only the sync failed; do not re-run ship, run `git switch "$(just base)" && git pull --ff-only`. |
| CR-kit-9 | minor | fix now | add smoke cases: `.claude/**` only change and `.agents/team.md` only change must NOT get the light lane; `ship --branch -x` and `ship abc` rejected; **plus the SEC-kit-10 case** (rename of a `.claude/...md` file into `docs/x.md` must require reviews). Use `$T/smoke.log` instead of `/tmp/kit-smoke.log` (also fix the usage comment on line 4). |
| CR-kit-10 | nit | fix now (one line) + covered | add `.agents/templates/**` and `.agents/project.md` to `LIGHT_EXCLUDE` (agents read both as instructions; safe direction). The rename question is answered by SEC-kit-10. Leave `.agents/plans/**` (local, uncommitted). |

## Developer instructions (dev-core, one agent, all fixes)

1. SEC-kit-10: in `diff_stats` (kit.py ~L392) use `git diff --numstat --no-renames -z` is optional; minimum is `--no-renames`, so a rename becomes delete (old path) + add (new path) and BOTH paths go through `matches()`. Then check the other rename-sensitive caller: kit.py ~L348 (`--name-status`) must read every path column of `R`/`C` rows, or also pass `--no-renames`. Grep for other `git diff` users of paths for review decisions (L235 `--name-only` lists only new names: add `--no-renames` there too if it feeds review/gate logic).
2. CR-kit-7, CR-kit-8, CR-kit-9, CR-kit-10, and SEC-kit-11 as above.
3. Unit/smoke: smoke cases above must fail without the fix (write the rename case first, see it take the light lane, then fix).
4. Feature record (Deferred list): add one line each: SEC-kit-2, SEC-kit-4, SEC-kit-12 (and SEC-kit-11 if deferred), CR-kit-4. Verify: T0+T1 (`just dev-gate` if it applies to kit files, plus `bash .agents/scripts/kit-smoke.sh`).
5. One push, Conventional commit e.g. `fix(kit): close rename bypass of light lane`, trailers `Refs:` per repo convention.

## How to apply (main checkout is on chore/kit-0.2.0)

A worktree cannot check out a branch that is already checked out in the main checkout, and agents must not touch the main checkout. Preferred:
1. Manager switches the main checkout to `develop` (`git switch develop`; it should rest there per delivery-process §3 anyway; the untracked backup dirs and `ci.yml.kit` carry over harmlessly). Needs the user's OK only if the switch complains.
2. Launch dev-core in its worktree directly on `chore/kit-0.2.0` (`git fetch -q; git switch chore/kit-0.2.0` inside the worktree, not `just new-branch`, which bases on develop). It commits and pushes that same branch: PR #9 updates in place, no second PR, no extra review file set.

Fallback if the manager prefers to leave the main checkout alone: dev-core works on a sub-branch `chore/kit-0.2.0-r2` created from `origin/chore/kit-0.2.0`, then pushes with `git push origin HEAD:chore/kit-0.2.0` (fast-forward only, no force). Do NOT open a PR for the sub-branch into develop. Afterwards the manager runs `git pull --ff-only` in the main checkout.

## Re-review

Same reviewers only: security-reviewer (SEC-kit-10, 11) and code-reviewer (CR-kit-7..10) on the new head, updating statuses in place. Then `just merge-check 9`, then `just ship 9`. No tester T2 needed beyond the smoke script (kit tooling, no app behaviour).
Estimate: dev-core ~120-180k tokens, reviewers ~40k each.
