# Security review: F1 / pr-13 (feat/F1-web-scaffold, slice 4)

Verdict: PASS (0 critical, 0 high, 0 medium, 1 low, 1 info)

## Supply chain assessment
- Lockfile (pnpm lockfileVersion 9): 338 packages, 338 with `integrity` hashes; no tarball URLs, git/github/http sources, or `link:`/`file:` deps. All resolve via the default registry.
- No package marks `requiresBuild` (no install scripts to run). Platform binaries are only `@rolldown/binding-darwin-*` and optional `fsevents`, both expected.
- No `deprecated` entries.
- Extra devDeps beyond plan (@types/react, @types/react-dom, @types/node, @eslint/js, globals, eslint-plugin-react-hooks, @testing-library/user-event): all mainstream, first-party or long-established maintainers (DefinitelyTyped, ESLint org, React org, Testing Library org, sindresorhus). Dev-only, not shipped in the bundle. Acceptable; none are typosquat-shaped.
- Runtime deps limited to react, react-dom, react-router, @tanstack/react-query, openapi-fetch (matches plan).
- Browser hygiene: eslint bans `dangerouslySetInnerHTML`; no secrets, no eval, no outbound URLs in src.

## Findings
### SEC-F1-1 (low, supply chain): no install-script allowlist or release-age guard
web/ has no `.npmrc` / `pnpm-workspace.yaml` pinning `onlyBuiltDependencies` (or `minimumReleaseAge`), and caret ranges are used (lockfile pins exact versions). Today nothing runs scripts, but a future dep could.
Fix: add `onlyBuiltDependencies: []` (and optionally `minimumReleaseAge`), install with `pnpm install --frozen-lockfile` in `just setup`/CI.
Verify: `grep -c requiresBuild web/pnpm-lock.yaml` stays 0 on lockfile updates. Status: open, non-blocking.

### SEC-F1-2 (info): msw `worker.start` mock path
web/src/main.tsx:9 starts the service worker only under VITE_MOCK_API; confirm `public/mockServiceWorker.js` is not emitted in the production build (not part of this diff). Non-blocking.

## Not verified
Advisory audit (`pnpm audit`) not run (no network/installed tree in this review).
