# Tests review: F1 PR #13 (web scaffold, slice 4)

Verdict: SIGN-OFF

Ran on origin/feat/F1-web-scaffold: pnpm install --frozen-lockfile, typecheck, lint (max-warnings 0), test:ci. All clean. 3 files, 17 tests pass; coverage lines 86% (threshold 75).

- Disclaimer: asserted on "/", "/scanner", "/anything/else" and with the API failing (MSW http.all error); it lives in AppShell outside the Outlet. Wildcard route also wrapped by the shell. OK.
- format-inr: table covers 0, 999, 1,000, 99,999, 1,00,000, 1,23,45,678, negative, extra decimals, zero decimals, bad input. Lakh/crore grouping correct; string-only (no float).
- format-ist: 04:00Z -> 09:30 IST; 19:00Z rolls to 06 Jan. OK.
- MSW: setupServer with onUnhandledFrame "error", reset/cleanup per test, shared handlers array (empty until API slice).

Findings (non-blocking):
- TS-F1-1 (low): formatInr truncates rather than rounds (1234.567 -> 1,234.56); pinned by a test. Confirm truncation is intended for display; no half-up case tested.
- TS-F1-2 (low): App.tsx and main.tsx are not covered (App.tsx 0%); acceptable for scaffold.

Not verified: Playwright (CI only), live browser rendering, dev:mock worker.
