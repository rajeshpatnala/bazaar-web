# Code review F1 / PR #13 (feat/F1-web-scaffold, slice 4)

Verdict: APPROVE WITH MINORS. Blockers: none. Major: none.

Checked: permanent disclaimer, INR/IST formatting, owner rules, red-flag hits, deps. Gate result and lockfile not re-run by reviewer.

## Verified
- Disclaimer: `AppShell` renders `<Disclaimer/>` as sibling of `<Outlet/>`, outside routes; no props/dismiss; both route trees (`/` and `*`) use AppShell, so it shows on 404 too. Test asserts visibility and `contentinfo`.
- Owner rules: no `position: sticky/fixed`, no scroll listeners or scroll-jacking in CSS/TS. Shell is a flex column, `min-height: 100vh`, footer flows after main (not pinned). Home section is tiny, fits viewport. `prefers-reduced-motion` honoured.
- INR: string-only grouping (no float), Indian lakh/crore grouping correct. IST: fixed `Asia/Kolkata` zone, UTC epoch input, tests cover zone and date rollover.
- Red-flag hits: all in test files or the ESLint rule banning `dangerouslySetInnerHTML` (justified). `main.tsx` MSW start is gated on `VITE_MOCK_API`, dynamic import, so excluded from prod path. No `any`, `console.log`, `innerHTML`.
- Vite proxy targets 127.0.0.1 only. Feature record `docs/features/F1-workspace-bootstrap.md` exists.

## Findings
- CR-F1-13-1 | minor | web/src/shared/lib/format-inr.ts:11 | `decimals` truncates (`"1500.75"` with 0 decimals gives `₹1,500`, not `₹1,501`). Silent truncation of money display is misleading, and the test pins it. Fix: round half-up on the string/BigInt, or throw/doc "truncates" and rename option. Status: open.
- CR-F1-13-2 | minor | web/src/shared/lib/format-ist.ts:7 | `hour12: false` can render `24:00` at midnight in some ICU builds. Fix: use `hourCycle: "h23"` and add a 00:xx test. Status: open.
- CR-F1-13-3 | nit | web/src/shared/lib/format-inr.ts | Regex rejects `+`, exponent and thousands separators in input; fine for API decimal strings, but note in doc comment. Status: open.
- CR-F1-13-4 | nit | web/package.json | Dependency versions are very new majors (eslint 10, vite 8, ts 6, react-router 8, msw 3); pinned by lockfile so acceptable. Supply-chain check left to security reviewer (SEC-F1-1 open there). Status: noted.
