# Code review: F1 budget settings (PR 8, chore/f1-budget-settings -> develop)

Verdict: APPROVE WITH MINORS (all addressed)

Moved from reviews/project-settings/code-review.md so merge-check finds it under F1. Scope: .agents/team.md (per_task_tokens 3,000,000 -> 4,000,000; tester_review behaviour-change -> large), .agents/decisions.md (+1 row). No production code, red-flag scan clean, no secrets.

## Findings

- CR-project-settings-1 | minor | .agents/decisions.md:7 | Status: fixed
  `%%` typo: current row already reads `1% / 3%` (verified on branch).
- CR-project-settings-2 | nit | .agents/decisions.md:7 | Status: fixed (see PR commit)
  Row to also record the budget / tester_review change.
