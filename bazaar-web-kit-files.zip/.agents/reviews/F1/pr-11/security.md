# Security review: F1 PR #11 (feat/F1-scaffold, slice 0 scaffold)

Verdict: PASS (no blockers). 1 medium (tech lead decides), 2 info.

Scope: Cargo.toml, Cargo.lock, 15 crate manifests, deny.toml, lints, toolchain, .editorconfig, small core/cli code. No secrets, no network code, no handlers in this slice. Red-flag hits: `unsafe_code = "forbid"` is a protective lint; the `.unwrap()` hits are all inside `#[cfg(test)]` tests (clippy `unwrap_used = deny` is set workspace-wide).

## SEC-F1-1 (medium, supply chain): `cargo deny check advisories` FAILS on a real advisory, not a DB fetch problem
- Where: Cargo.toml `chrono = "0.4.45"`, `chrono-tz = "0.10"` (Cargo.lock lines ~42 and chrono-tz 0.10.4); deny.toml `[advisories]` has no ignore list.
- Issue: Advisory DB fetched fine and produced exactly two errors: RUSTSEC-2026-0543 (chrono unmaintained, all versions) and RUSTSEC-2026-0555 (chrono-tz unmaintained, all versions; "no safe upgrade available"). licenses, bans and sources pass. Both are "unmaintained" notices, not vulnerabilities: no known exploit.
- Impact: no exploitable flaw today. CI supply-chain job will go red, and time handling underpins the "IST at the edges, UTC inside" rule, so a long-term replacement decision is needed.
- Fix: owner/tech lead decision. Short term, add to deny.toml `[advisories] ignore = [{ id = "RUSTSEC-2026-0543", reason = "..." }, { id = "RUSTSEC-2026-0555", reason = "..." }]` with an owner note and a review date (the file header already says to adjust with an owner note), then record an ADR in DECISIONS.md on keeping chrono or moving to `jiff`/`time` (the dep set was owner-approved on 2026-11-18, so do not swap in this PR).
- Verify: `cargo deny check advisories` exits 0 and the ignores carry reasons.

## SEC-F1-2 (info): deny.toml `[licenses.private] ignore = true`
Acceptable. Workspace crates are `publish = false` with a "Proprietary" licence; the setting only skips the licence check for those unpublished workspace crates. Third-party licence checks still run and pass. Minor: cargo-deny warns the "OpenSSL" allow entry is unused; consider removing it.

## SEC-F1-3 (info): dependency hygiene
- Positive: tower-http has `default-features = false` and no `cors`; bans on openssl-sys/native-tls pass; sources are crates.io only; Cargo.lock committed; toolchain pinned.
- The `bazaar-server` Cargo.toml lists tokio/tracing after other deps (cosmetic). `live-trading` feature is off by default, which is correct for the gate-only-order-path rule.
- `getrandom`, `subtle`, `axum-extra` cookie are present for the later launch-token session; re-review when used (constant-time compare, cookie flags).
