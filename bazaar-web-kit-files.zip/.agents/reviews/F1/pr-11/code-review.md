# Code review F1 slice 0 (PR #11, feat/F1-scaffold)

Verdict: APPROVE WITH MINORS

Scope: scaffold only (workspace manifests, lints, 15 crate stubs, `core::{clock,segment,mode}`, cli args, docs record). About 288 production lines, the rest is Cargo.lock. Gate result was not re-run by me.

## Red-flag scan
- `unsafe_code = "forbid"` (Cargo.toml:60): it is the lint setting, not unsafe code. OK.
- `unwrap()` hits (cli lib.rs, core clock/mode/segment): all inside `#[cfg(test)]`. The crates allow `unwrap_used` only under `cfg(test)`. OK.
- No `Utc::now`, floats, hardcoded market facts or `live-trading` default. `clippy.toml` bans wall-clock reads. OK.

## Checks
- Dependency edges match the layering: core has no internal dependencies, and server depends only on core plus optional broker. `live-trading` is in no `default` feature. It is forwarded from broker through cli and server as an optional dependency. OK.
- `ExecutionMode` defaults to `Paper`, rejects unknown and wrong-case values, and is documented as read from risk.toml only. Tests cover each case.
- `Segment` and `InstrumentKind` have tests for parse, reject and serialise. Leaving `all` out of `InstrumentKind` is reasoned and recorded in the docs.
- `docs/features/F1-workspace-bootstrap.md` is present and its "What was built" section is filled in for slice 0.

## Findings

CR-F1-1 (minor) Cargo.toml:`[workspace.lints.cargo]`
Setting `unused_dependencies` and `unused_workspace_dependencies` to `allow` hides dead dependencies across the whole workspace. The docs record says to revert it in slice 9, but nothing enforces that.
Fix: keep the slice 9 revert as an explicit plan task, and list it in the docs record under Deferred, which is currently empty.

CR-F1-2 (minor) Cargo.toml:`rust-version = "1.100"`
This is an unusual MSRV value. The owner approved the pin to 1.100.0 on 2026-11-18, so I am not blocking. Please confirm `rust-toolchain.toml` and `rust-version` agree on every CI and dev machine.

CR-F1-3 (nit) crates/core/src/segment.rs:9,24
The enum variants have no doc comments. Add one-liners when `missing_docs` is enabled.

CR-F1-4 (nit) crates/cli/src/lib.rs:20
The doc comment says `data_dir` "defaults to `data`". The `default_value` already shows this in `--help`, so the sentence is redundant.

CR-F1-5 (nit) crates/server/src/main.rs
`fn main() {}` is a stub. This is acceptable for slice 0, and the doc comment says which slice fills it.

Blockers: none. Major: none.
