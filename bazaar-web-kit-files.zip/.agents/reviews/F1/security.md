# F1 - security review - chore/f1-budget-settings (PR #8)

Verdict: PASS
Round: 1

| id | severity | category | file:line | issue | impact | fix | verify by | status | tech-lead decision |
|---|---|---|---|---|---|---|---|---|---|
| SEC-F1-1 | info | supply-chain | .github/workflows/ci.yml:117 | `gitleaks/gitleaks-action@v2` is pinned to a floating major tag, not a SHA (also true of the other actions in the file). | Low. A compromised tag would run with a read-only token. | Optional: pin third-party actions to SHAs in a later CI hardening slice. | n/a | open | |

Notes (no findings):
- The change adds job-level `permissions: contents: read` and `pull-requests: read` to `secrets-scan` only (ci.yml:111-113). Both are read-only, and gitleaks-action needs them to list PR commits (this fixes the 403). A job-level block overrides the workflow default, and the default is already `contents: read` (line 7-8), so the only widening is `pull-requests: read` on this one job. No write scopes, no `id-token`, and no new secrets or triggers. Trigger is `pull_request`, not `pull_request_target`.
- `GITHUB_TOKEN` was already passed to the step. Nothing else in the workflow changed.
- `.agents/team.md` and `.agents/decisions.md` hold only config values and a decision line. They contain no secrets or code. Red-flag scan: no hits.
