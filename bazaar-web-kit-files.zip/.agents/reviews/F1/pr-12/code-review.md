# Code review: F1 slice 1 (core types), PR #12, branch feat/F1-core-types

Verdict: APPROVE WITH MINORS (head c6a4798, after fix commits 556bf11 and c6a4798; 0 blockers, 0 major, 1 nit open)

## Answers to the lead's questions
- f64: none anywhere in the diff. Wall clock: only `SystemClock::now_ist`, the single allowed read, behind a documented `#[allow(clippy::disallowed_methods)]`. Justified.
- Rounding policy: sound as an internal ledger rule (banker's to paise, nearest tick with halves away from zero). Caveats are now documented in money.rs.
- Frozen `crates/core/Cargo.toml` edit: only adds the approved workspace deps `rust_decimal` and `thiserror`. Acceptable.

## Findings

| Id | Sev | Where | Issue | Status |
|---|---|---|---|---|
| CR-F1-1 | major | money.rs | Panicking `Add`/`Sub` and unchecked `raw / tick` | fixed: operators removed (only `Neg` remains), `checked_sub` and `checked_div` added, overflow tests added |
| CR-F1-2 | minor | disclaimer.rs | Doc claimed a Rust-vs-TS equality test that did not exist | fixed: doc corrected; slice 9 owns the test (track it there) |
| CR-F1-3 | minor | money.rs | Banker's rounding may differ by 1 paisa from contract notes | fixed (docs): caveat documented, reconcile per call site in the cost model |
| CR-F1-4 | minor | money.rs | Nearest-tick snapping is not directional | fixed (docs): normalisation-only note; directional floor/ceil must land before any order path; `-0` test added |
| CR-F1-5 | minor | Cargo.toml | `rust_decimal` default features pulled in rand, borsh, wasm-bindgen | fixed: `default-features = false` with std, serde-with-str, maths (confirm Cargo.lock shrank in CI) |
| CR-F1-6 | nit | error.rs:17 | `NegativePrice` added, but `NegativeQuantity` message still reads "negative quantity or price"; `#[allow]` could be `#[expect]` | open (nit, non-blocking): change the message to "negative quantity" |

## Other notes
- Also verified: `InvalidAmount` echo bounded to 32 chars (tested); `Price` has no `Deserialize`, documented (parse, don't validate).
- Records: no `docs/features/F1-*.md` update in this slice; confirm it lands with the final slice.
- Red-flag hits: all `unwrap` hits are inside `#[cfg(test)]`; no secrets, no hardcoded tick or lot sizes.
