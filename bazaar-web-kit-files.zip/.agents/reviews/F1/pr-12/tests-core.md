# Tests review: F1 slice 1, PR #12 (feat/F1-core-types), area: core
Verdict: SIGN-OFF

Ran: `cargo nextest run -p bazaar-core --features test-util` -> 23/23 pass. No tests added.

Verified
- Reference value: 1234.55 x 75 = 92591.25 (exact), tick 0.05 snap-stable.
- Half-even paise: 0.125->0.12, 0.135->0.14, -0.125->-0.12 (symmetric).
- Tick snapping: 100.02->100.00, 100.03->100.05, exact half 100.025->100.05, 0->0; tick<=0 and negative raw error; proptest multiple-of-tick and within half a tick.
- Overflow returns Err (checked_add/mul, Lots::to_qty); lot size 0 rejected; serde is string-only for Money.
- FakeClock: IST timezone, advance/set deterministic; SystemClock reports Kolkata.

Findings (non-blocking)
- TS-F1-1 (low): `Add`/`Sub`/`Neg` on Money use unchecked Decimal ops, which panic on overflow (untested). Prefer checked paths in money-critical code or document the limit.
- TS-F1-2 (low): negative price yields `DomainError::NegativeQuantity`; a dedicated variant would be clearer. No test for snap overflow with huge raw / tiny tick.
- TS-F1-3 (info): Price has Serialize but no Deserialize (intended: must pass snap); no test asserts that.
