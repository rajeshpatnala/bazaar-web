# Security review: F1 / pr-12 (feat/F1-core-types)

Verdict: PASS (0 critical, 0 high, 0 medium, 2 low, 1 info)

Scope: money, clock, error, disclaimer, testutil; core Cargo.toml adds rust_decimal and thiserror; Cargo.lock.
Note: the pack listed a prior SEC-F1-1 as open, but no earlier security.md exists at this path; reviewed from scratch.

## Red-flag hits
- clock.rs:19-21 `#[allow(clippy::disallowed_methods)]` + `Utc::now()`: justified, the single wall-clock read behind the Clock trait. OK.
- `unwrap()` hits in money.rs / testutil.rs: all inside `#[cfg(test)]`. OK.

## Findings

### SEC-F1-1 (low, robustness: no panics in library code) - OPEN
- Where: crates/core/src/money.rs `impl Add/Sub/Neg for Money` (~lines 75-95)
- Issue: `Decimal` `+`/`-` panic on overflow, although checked_add exists. Values will later come from parsed external data.
- Impact: a crafted extreme amount could panic the server (DoS, local only).
- Fix: drop the operator impls, or make them saturating; prefer `checked_add`/`checked_sub`.
- Verify: unit test with `Decimal::MAX + 1`.

### SEC-F1-2 (low, input bounds) - OPEN
- Where: money.rs `FromStr for Money` / `Deserialize` (serde str)
- Issue: `InvalidAmount(String)` echoes the full input into the error and its Display. An unbounded input could end up in logs or problem+json.
- Fix: truncate the echoed string (for example to 32 chars) or omit it. Add a length cap at the API edge.
- Verify: test that a 10k-char input yields a bounded message.

### SEC-F1-3 (info, supply chain)
- rust_decimal 1.43.0 and thiserror 2.0.21 are justified (Decimal money rule, error derive). Lock adds only registry crates with checksums. The transitive set grows (rand 0.8/0.9, borsh, wasm-bindgen, zerocopy, getrandom 0.2/0.3 duplicates). Consider disabling rust_decimal default features if not needed.
- Verify: run `just` supply-chain recipe (cargo deny / audit) in CI; I did not find advisories in the diff, but did not run the tools.

## Checklist notes
- No secrets, env or logging added. No network, SQL, or file I/O except `fixture_path` (test-util feature, constant join, no input traversal beyond the caller's `rel`; test-only).
- `Price` has no `Deserialize` (parse, don't validate). Good.
- Disclaimer constant is present and exact.
- FakeClock mutex poisoning handled without panic.
