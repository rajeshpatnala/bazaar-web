# Tests review: PR #14 (F1 slice 5, server security) - tester

Verdict: SIGN-OFF

Ran `cargo nextest run -p bazaar-server` at 27510a0: 26/26 pass.

Covered: bad/missing Host 403; Origin required and exact on non-GET; no session 401 problem+json; forged cookie 401; wrong CSRF 403, right CSRF ok; launch token single-use, wrong token does not burn the real one; launch TTL (Duration::ZERO) and Kite nonce TTL (backdated Instant), no sleeps; cookie HttpOnly/SameSite=Strict/Path=/; CSP exact-string contract; security headers on rejections; exempt list pinned; dev origin only in dev builds; redacted Debug; problem+json error variants.

Findings:
- TS-F1-1 (nit): TTLs use std Instant, not the Clock trait; acceptable.
- TS-F1-2 (nit): no just-inside-TTL token test beyond the happy path.
- CSP is an assert_eq pin, not an insta snapshot; fine.

Not verified: cookie Secure/Max-Age, Playwright, live browser.
