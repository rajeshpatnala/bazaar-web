Verdict: PASS

# Security review: PR #14 (feat/F1-server-security, F1 slice 5)

Scope: crates/server/src/security.rs, error.rs, Cargo manifests. Blockers: none (0 critical, 0 high, 0 medium, 3 low, 2 info).

## Checked, no issue
- Token entropy: launch token and session id and CSRF are 32 bytes from `getrandom::fill` (64 hex chars); nonce 16 bytes. RNG failure maps to `SecurityError::Rng` (no panic, no fallback to a weak source).
- Constant-time: launch token and CSRF compared with `subtle::ct_eq`. Session lookup is a HashMap hit on a 256-bit unguessable id (not a timing concern). Length differences leak only the fixed length.
- Launch token: single use, 600 s TTL, a wrong guess does not burn it, and the check and consume happen under one mutex (no race). The launch URL is returned only by `launch_url` (stdout in main), never logged.
- Cookie: HttpOnly, SameSite=Strict, Path=/, no Domain. No Secure on plain-HTTP loopback is correct per bz-security; a test pins this.
- DNS rebinding: exact Host allowlist (127.0.0.1:port, localhost:port), missing Host refused, case-insensitive; dev origin is added to Origin only, never to Host. Origin exact-match on non-GET and on upgrades; `null`, missing and suffix tricks refused; no CORS; OPTIONS refused.
- Error bodies: fixed strings per code; rejections are mapped via `from_status` (serde and axum detail text is dropped); `Internal` never carries a cause.
- Logging: `path_only_span` drops the query (`/auth?token=`, Kite callback); `Session`, `AuthQuery` and `Security` Debug output are redacted (test pins it).
- Loopback guard: only 127.0.0.1 is accepted; `::1`, `::` and `0.0.0.0` fail startup. CSP is the frozen string with no `unsafe-*`.
- Dependencies: `subtle`, `getrandom`, `axum-extra`, `tower` are already workspace deps; this PR only adds serde, serde_json, thiserror and a dev-dep feature. No new advisory surface seen.

## Findings

### SEC-F1-5-1 (low, session lifecycle): sessions never expire and the map is unbounded
security.rs `new_session`, `session`. A session lives until process exit. Impact is minimal today (only one launch token can ever mint a session, so growth is bounded to 1), but a future re-login path would make it unbounded. Fix: store `Instant`, apply an idle or absolute TTL in `session()`, and cap the map; add a logout that removes the entry. Verify: a unit test with a zero TTL returns 401.

### SEC-F1-5-2 (low, error mapping): backstop labels every bare 403 as `forbidden_origin`
error.rs `from_status` (`StatusCode::FORBIDDEN => ForbiddenOrigin`). A future handler returning a plain 403 would tell the UI "Origin not allowed", which is misleading, though not a leak. Fix: add a generic `Forbidden` variant and code, and keep the guard variants only for the guards. Verify: a backstop test with a bare 403.

### SEC-F1-5-3 (low, launch token): an expired, unused token stays in memory and `launch_url` still prints it
`launch_url` returns the token even after the TTL has passed, so main could print a dead link. Fix: return `None` when `born.elapsed() >= launch_ttl`, and optionally clear the slot. Verify: a test with `with_launch_ttl(Duration::ZERO)` expects `launch_url == None`.

### SEC-F1-5-4 (info, headers): guard rejections carry no CSP, nosniff or no-store
In the test wiring `security_headers` sits inside `host_guard`, so 403 Host and Origin responses lack the headers (a test comment acknowledges this). The bodies are JSON, so the risk is negligible. When wiring `app::build`, put `security_headers` outermost so it covers all responses, and check that the backstop does not overwrite it.

### SEC-F1-5-5 (info, wiring): this slice does not wire the layers or `main`
Guard order, the exempt list (`/healthz`, `/auth`, Kite callback), the `take_kite_nonce` use in the callback, `ensure_loopback` at bind and the stdout-only launch URL are not exercised end to end here. Re-check these in the slice that wires `app::build` and `main`. The pinned exempt list and the nonce unit tests are good.
