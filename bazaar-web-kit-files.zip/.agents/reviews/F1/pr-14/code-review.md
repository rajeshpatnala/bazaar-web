Verdict: APPROVE WITH MINORS

# Code review F1 slice 5 (PR #14, feat/F1-server-security)

Scope: crates/server/src/security.rs, error.rs, Cargo.toml and Cargo.lock. Not run: the gate (build-runner). The last ~46 diff lines (the nonce test tail) were not shown in the pack.

## Checks
- No panics in library code: pass. Every `unwrap` is under `#[cfg(test)]` with a scoped allow. The poisoned-mutex path uses `PoisonError::into_inner`. Serialisation uses `unwrap_or_default`. RNG failure maps to `SecurityError::Rng` and then a 500.
- Loopback only: pass. `loopback_addr` is the only constructor and `ensure_loopback` rejects `0.0.0.0`, `::`, `::1` and LAN addresses. The test covers these. There is no CORS layer.
- Session coverage: partial. See CR-F1-S5-1.
- problem+json: pass. Variants map one to one to a stable `code`. Details are fixed strings. Rejections for JSON, query and path go through `ApiError`. `problem_backstop` converts bare 4xx/5xx responses. Tests cover 400, 422, 415, 413 and 405.
- Deps: serde, serde_json and thiserror are pinned workspace deps and are used in production code. The tower `util` dev-dep is needed for `oneshot`. The Cargo.lock delta is consistent.
- Red-flag hits: justified. The two `unused_async` allows carry a reason comment. The `0.0.0.0` hit is only a doc comment.

## Findings

### CR-F1-S5-1 (minor) Session requirement is opt-in and not tested structurally. Status: open
security.rs:600 and :813. `EXEMPT_PATHS` is only a constant that a test pins. No guard reads it. Protection depends on `app::build` applying `route_layer(session_guard)` to every non-exempt route. The tests use a hand-built router, so nothing proves that every real route except `/healthz`, `/auth` and the Kite callback needs a session. The unprotected `/open` test route shows the guard is opt-in.
Fix: in the `app::build` slice, add a router-level test. It should enumerate the OpenAPI paths, call each without a cookie, and expect 401. The exempt paths are the only exceptions, and the Kite callback should be tested as reachable without a session. Alternatively, make `session_guard` skip paths from `EXEMPT_PATHS` and apply it with `.layer`. That way it fails closed for new routes.

### CR-F1-S5-2 (minor) Guard order in the tests contradicts the docs. Status: open
security.rs:936-938 and the module doc (:3). The docs say `host_guard` is outermost. In the test router `.layer(host_guard)` is followed by `.layer(origin_guard)`, which makes `origin_guard` the outermost, so it runs first. A bad Host on a POST therefore returns `forbidden_origin` rather than `forbidden_host`. The tests pass only because they never combine the two. Also, `security_headers` sits inside `host_guard`, so guard rejections carry no CSP, nosniff or no-referrer headers. The doc says "on every response", and the test comment at :1211 admits the gap.
Fix: in `app::build`, apply layers in this order, innermost first: `security_headers`, `problem_backstop`, `origin_guard`, `host_guard`. `security_headers` then wraps the rejections too. Add a test that a Host-rejected response carries CSP, and one that a bad Host plus a bad Origin returns `forbidden_host`.

### CR-F1-S5-3 (minor) Generic 403 maps to `forbidden_origin`. Status: open
error.rs:324. `from_status(FORBIDDEN)` returns `ForbiddenOrigin`, which mislabels any other bare 403. The stable `code` is what the UI switches on. Return a neutral `Forbidden` variant, or document this as intended.

### CR-F1-S5-4 (minor) Test gaps. Status: open
- `ApiPath` has no test.
- `bad_query_is_problem` and `wrong_token_does_not_burn_the_real_one` assert only `is_client_error()`. Pin the status and `code` (probably 400 `bad_request`).
- `unknown_api_is_404_problem` does not check the content type or code.
- There is no test that the `Session` and `AuthQuery` `Debug` output is redacted.
- There is no test that the launch token never appears in a span. `path_only_span` is untested.

### CR-F1-S5-5 (nit) Session lifetime. Status: open
Sessions have no expiry or revocation, and the cookie has no `Max-Age`. The set is bounded in practice because the launch token is single use. Launch TTL uses `Instant`, which does not advance during macOS sleep, so the TTL stretches across a sleep. Both are acceptable for a single-user local app. Record them in the security notes.

### CR-F1-S5-6 (nit) Records. Status: open
No `docs/features/F1-*.md` update is in this slice. Confirm the record is added at the end of F1.
