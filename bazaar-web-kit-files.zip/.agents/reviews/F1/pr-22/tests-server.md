# Tests review: PR 22 (F1-s6 server-app), area: server
Verdict: SIGN-OFF (0 blockers, 3 minors). `just test` PASS.

Coverage vs AC: AC5 healthz no session (app.rs) + loopback refusal (security.rs:954, slice-4 unit); AC6 401 on every OpenAPI path, forbidden_host, forbidden_origin (missing), csrf_invalid (missing), unknown /api 404 problem+json; AC7 cookie flags + single use here, wrong/expired token in security.rs:668/683; AC8 paths prefix + Problem schema.

- TS-22-1 (minor): no router-level test for foreign Origin (present but wrong) or wrong (non-empty) CSRF token on a non-GET; only missing cases covered. Add two cases to post_without_origin_or_csrf_is_refused. Note: /api/v1/status POST route may not exist, so test passes via guard order; acceptable, but add a comment.
- TS-22-2 (minor): AC8 "money-typed schemas are string" and the schema.d.ts no-diff are not asserted in openapi_contract (no money types yet in this slice; fine now, add when first Decimal DTO lands). `just openapi` no-diff is T2.
- TS-22-3 (minor): TestApp temp dist dirs under temp_dir are never removed (Drop impl missing); `dist` field unused for cleanup. Use tempfile::TempDir.

Not verified (T2): UI disclaimer/session-ended AC9-10, Playwright, openapi regeneration diff, timeout (30s) and body-limit 413 problem+json behaviour (no test).
