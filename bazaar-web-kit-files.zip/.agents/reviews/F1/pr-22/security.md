# Security review: PR 22 (F1-s6 server-app), branch feat/F1-server-wiring

Verdict: PASS. Blockers: 0. Critical 0, high 0, medium 0, low 1, info 1.

Walked: red-flag hits (all test-only unwrap or documented clippy allows; none in production paths), layer order, auth coverage, input limits, static serving, deps.

Checked and OK
- Layer order (last `.layer` outermost): security_headers > TraceLayer(path only) > host_guard > origin_guard > problem_backstop > timeout (30s) > body limit (1 MiB). Headers appear on rejections (tested).
- `/api/v1/**` sits behind session_guard (outermost of route_layers) then csrf_guard; public set is only `/healthz`, `/auth`, and the `/api/{*rest}` 404 backstop. Test enumerates every OpenAPI path for 401.
- No order or write endpoint added; handlers are GET only and return mode, live_enabled, time, version (no secrets). `live_enabled` is compile-time `cfg!`; `live-trading` not in default.
- Static serving via tower-http ServeDir (traversal-safe); unknown `/api/*` never falls through to index.html.
- AppState Debug omits security/session data. Main binary only has `openapi` subcommand (no socket, no config read yet).
- New deps are dev-only (chrono, chrono-tz, bazaar-core test-util); no runtime supply-chain change.

Findings
- SEC-22-1 (low, hardening) crates/server/src/app.rs:165-170: when `web_dist/index.html` is absent at startup the fallback is fixed for the process lifetime; harmless. The `web_dist` is a config-supplied path; slice 7 must keep it fixed/non-user-input. Verify: slice 7 review of main.rs wiring.
- SEC-22-2 (info) crates/server/src/routes/status.rs:430: `/healthz` is behind host_guard/origin_guard (good); keep it data-free as more fields are added to status.
