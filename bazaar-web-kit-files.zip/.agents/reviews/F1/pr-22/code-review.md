# Code review: F1 slice 6 server-app (PR 22, feat/F1-server-wiring)

Verdict: APPROVE WITH MINORS. Blockers: 0. Major: 0. Minor: 3. Nit: 1.
Gate result not re-run by me; per the pack, tests are in-process router tests.

Checked: layer order (last `.layer` is outermost: security_headers, trace, host, origin, backstop, timeout, body limit) matches the module doc. Session guard runs before the CSRF guard (it was added last with `route_layer`), which is correct. `/healthz` and `/auth` are public and every OpenAPI path is 401 without a cookie (tested). No order route. DTOs are separate from domain types, and `live_enabled` comes from `cfg!`. Red-flag hits are all test-only unwraps under `allow`, or `unused_async` on axum handlers with a stated reason, so they are justified.

## Findings

- CR-22-1 minor: `crates/server/src/app.rs:174-179`. The 1 MiB body limit and the 30 s timeout are literals, and the module doc claims a 408 or 413 also becomes problem+json, but no test covers either. Add one router test for an oversize POST body (413 with problem+json). A 408 test could use a tiny injected timeout, or be deferred. Fix: test it, or soften the doc claim.
- CR-22-2 minor: `docs/features/F1-workspace-bootstrap.md`. The record has no slice 6 entry: the new routes, layers, `openapi` subcommand and `AppState` are not described. It does add slice 3 and CR-21-x text that belongs to PR 21, which looks like a base or merge overlap. Add a "Slice 6 (server-app, PR 22)" bullet. Also confirm the AC4 wording change is not duplicated against develop.
- CR-22-3 minor: `crates/server/tests/app.rs:606`. The CSRF success path (POST with valid Origin, cookie and `X-CSRF-Token` passing the guard) is untested. Only the refusals are covered. There is no POST route yet, so it can be deferred to the first mutating route. Record it as a follow-up.
- CR-22-4 nit: `crates/server/src/app.rs:169`. The missing-UI fallback returns plain text with 200. Consider 503 for it, or keep 200 deliberately (the test asserts 200). Optional.
- Note (not a finding): `openapi::router()` is built twice (in `app::build` and in `document()`). This is harmless.
