# Tests review: PR 24 (F1-s7 server-startup), area: server
Verdict: SIGN-OFF (0 blockers, 2 minors). \just test` PASS at 9717a11.That is the one thing blocking just ship 24`

Covered: bind_addr is 127.0.0.1 and loopback; resolve_port priority flag > env > default, trim, bad/overflow/zero rejected; clap accepts serve/--port and rejects --host. `openapi` JSON parses and paths are /api/v1/ via tests/app.rs openapi_contract (library call).
- TS-24-1 (minor): the `bazaar-server openapi` subcommand itself (stdout parses) is not run as a process test; the library document is. Acceptable; consider an assert_cmd test.
- TS-24-2 (minor): non-loopback refusal is tested only in security.rs (ensure_loopback), not via bind_addr; bind_addr cannot take a host, so low value.
Not verified (by instruction): `serve` run, SIGTERM shutdown, dotenv error handling, browser open.
