# F1 - code review (code-reviewer, by envelope) - feat/F1-server-startup

Verdict: APPROVE
Round: 2 (re-review: CR-24-1..5 all fixed; optional BAZAAR_CONFIG_DIR test not added, not required)
Reviewed by: envelope (one tool-free Claude call)

| id | severity | file:line | issue | why it matters | suggested fix | status | tech-lead decision |
|---|---|---|---|---|---|---|---|
| CR-24-1 | question | crates/server/src/main.rs:1 | The diff touches only main.rs and deny.toml. There is no docs/features/F1-*.md update in this change. | A feature PR must add or update its F<n> record. If slice 7 is the final F1 slice, the record is missing, and that is a major finding. | Confirm whether the F1 record is added or updated elsewhere in this PR. If it is not, add it, covering the serve command, the loopback bind and the env vars. | fixed |  |
| CR-24-2 | minor | crates/server/src/main.rs:41 | parse_port accepts 0. The OS then picks a random port, but Security::new(port) and the launch URL are built from port 0, so the Host/Origin allowlist and the URL will not match the real port. | A mistyped BAZAAR_PORT=0 gives a server that looks up but refuses every request with forbidden_host. | Reject 0: `.filter(/p/ *p != 0).context(...)`. Add a test for `parse_port(Some("0"))`. | fixed | fix now if cheap (auto) |
| CR-24-3 | minor | crates/server/src/main.rs:73 | The child process from open_browser is spawned and never waited on, which leaves a zombie process until the server exits. shutdown_signal also handles only Ctrl-C, not SIGTERM. | This is a small resource leak, and termination by a supervisor or `kill` skips the graceful shutdown. | Drop the Child, or call `.spawn().map(/mut c/ { std::thread::spawn(move // { let _ = c.wait(); }); })`. Add a SIGTERM handler via tokio::signal::unix on unix. | fixed | fix now if cheap (auto) |
| CR-24-4 | minor | crates/server/src/main.rs:88 | `let _ = dotenvy::dotenv();` discards all errors, so a malformed .env fails silently. The `serve()` wiring (config dir env var, mode, launch URL) has no test beyond the helper functions. | The user then gets confusing missing-config behaviour. | Ignore only the NotFound error and surface parse errors. Optionally add a test for the BAZAAR_CONFIG_DIR override. | fixed | fix now if cheap (auto) |
| CR-24-5 | nit | crates/server/src/main.rs:147 | The test web_dist_is_fixed asserts that a constant equals its own literal. | It tests nothing about behaviour. | Drop it, or assert on the ServeDir path actually used by app::build. | fixed | fix now if cheap (auto) |
