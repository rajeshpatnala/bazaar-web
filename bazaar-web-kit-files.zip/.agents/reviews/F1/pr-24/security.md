# F1 - security review (security-reviewer, by envelope) - feat/F1-server-startup

Verdict: PASS
Round: 1
Reviewed by: envelope (one tool-free Claude call)

| id | severity | file:line | issue | why it matters | suggested fix | status | tech-lead decision |
|---|---|---|---|---|---|---|---|
| SEC-24-1 | low | crates/server/src/main.rs:37 | The port comes from the BAZAAR_PORT env var. The security rule says the port is set via `--port` only and that no env var exists for the bind. The host stays non-configurable, so loopback is still enforced by ensure_loopback. | This is a deviation from the written policy. It does not weaken the loopback guarantee. | Either add `--port` and drop the env var, or record the rule change. A human should decide, because this is policy. | open | fix now if cheap (auto) |
| SEC-24-2 | low | crates/server/src/main.rs:91 | The new env var BAZAAR_CONFIG_DIR redirects where config is loaded from, including risk.toml with execution_mode. | Anyone who can set the environment can load a different config. The hard_limits loader check still applies. Process env is normally in the same trust domain, so this is a hardening gap only. | Keep the override for tests and dev only, or document it. Verify that the loader still enforces hard_limits and rejects execution_mode = live without the opt-in. | open | fix now if cheap (auto) |
| SEC-24-3 | info | crates/server/src/main.rs:107 | The launch URL, which contains the one-time token, is printed to stdout and passed as a command-line argument to `open` or `xdg-open`. Other local users can see it in `ps` for a moment. | The token is one-time and short-lived, and a wrong guess does not consume it. The exposure is low, but a race is possible on a shared machine. | Accept this and note it in the record. Alternatively, use the opener only in dev, or print the URL only. | open | fix now if cheap (auto) |
| SEC-24-4 | info | crates/server/src/main.rs:104 | The token is correctly kept out of tracing. The tracing filter comes from RUST_LOG, so request logging in app::build could log the query string. | I cannot see app::build or the TraceLayer config in this diff. | Confirm that no TraceLayer logs the URI query and that `/auth` logs only the path. | open | fix now if cheap (auto) |
