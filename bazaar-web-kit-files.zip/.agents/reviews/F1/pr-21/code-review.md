# Code review F1 / PR 21 (feat/F1-core-calendar, slice s3)

Verdict: APPROVE WITH MINORS (1 question must be answered by tech lead before merge)

Gate result: not re-run by reviewer (not in handoff). Scope: crates/core/src/calendar.rs only.

## Findings

### CR-21-1 question - calendar.rs:~120 `Weekday::Sat | Weekday::Sun` literal in non-test source
AC4 says "no hour, date or weekday literal in non-test source". The weekend test is a weekday literal. The dev note says calendar.toml has no weekend key, so it cannot be config-driven today.
My view: accept as a documented exception. The Sat/Sun weekend is a structural fact, not a changeable market fact (unlike holidays, hours, lot sizes). The module doc states it, and special sessions (e.g. Saturday muhurat) override it from config. It is the single such literal, and no hour or date literal exists.
Decision needed (tech lead): (a) accept and amend AC4 wording to "no hour/date literal; Sat/Sun weekend is the only weekday fact", or (b) add a `weekend` key to calendar.toml schema (`weekend = ["sat","sun"]`, default) and read it. Recommend (a).

### CR-21-2 minor - no feature record in diff
Feature PRs should add or update `docs/features/F1-*.md`. Only calendar.rs is in the diff. Confirm the F1 record covers the calendar (query semantics: mock session not tradable, clearing holiday not closing, shift-to-prior, OutOfRange).

### CR-21-3 nit - calendar.rs next/prev_trading_day loops
Termination relies on the year check hitting OutOfRange (covered_years is finite) and so is bounded. Fine; a short comment saying so would help the next reader.

## Focus checks
- No panics in library code: all `unwrap()` hits (lines 284-497) are inside `#[cfg(test)]`. Library code returns `Result<_, CalendarError>`; `succ_opt/pred_opt` handled; `from_local_datetime().single()` mapped to `InvalidLocalTime`. OK.
- IST/Clock: library takes `DateTime<Utc>` instants and converts with `chrono_tz::Asia::Kolkata`; no `Utc::now()`/`Local::now()`. A test exercises a `Clock` fake. OK.
- No hour/date literals in library source; session windows, holidays, specials and covered years all come from config. Out-of-range year errors instead of guessing. OK.
- Tests cover weekend, holiday per segment, clearing holiday, special (Sat muhurat), mock, regime change (2026-07-01), boundary seconds, out-of-range, no-session error, consecutive holidays, proptest roundtrip. Good.
- Red-flag scan: only test unwraps; no f64, no `#[allow]`, no unsafe.

File: /Users/rajesh/projects/bazaar-web/.agents/reviews/F1/pr-21/code-review.md

## Tech-lead decisions (2026-11-19)
- CR-21-1: accept (a). The Sat/Sun weekend is a structural fact, not market data; special sessions override it from config. AC4 wording amended in plan and feature record: "no hour or date literal in non-test source; Sat/Sun weekend is the only structural weekday fact". Decision: reject (no code change; wording amended).
- CR-21-2: reject: docs/features/F1-workspace-bootstrap.md is the single F1 record; slice 9 fills "What was built" (calendar semantics line added now).
- CR-21-3: defer: comment on loop termination added by the next dev touching calendar.rs (F2 calendar data).
