Verdict: SIGN-OFF

# Tests review: PR 21 (F1-s3 core-calendar), area calendar

No blockers. 21 calendar tests pass (`cargo test -p bazaar-core calendar`). No tests added by me.

## AC4 coverage map
- weekend: covered (Sat/Sun is_trading_day). Gap TS-21-2.
- holiday: covered (is_trading_day, session_at, close_time error, per-segment, clearing, consecutive).
- special session: covered (Saturday muhurat, mock). Gaps TS-21-3.
- out-of-range: covered (is_trading_day, next/prev, session_at).
- expiry shift: covered (holiday, weekend, unchanged, consecutive, per-segment).
- session boundary: covered (non-F&O, F&O auction, regime change at 2026-07-01, start inclusive / end exclusive).

## Findings
- TS-21-1 (medium) Proptest is weak: one property, Equity only, 2026 only, and `prev(next(x)) >= start` is a loose bound (should be `==`). Missing: shift idempotent and never later than input; shift result is a trading day; `session_at` never errors in range and is Closed on non-trading days; other segments. `cal()` reloads the file per case.
- TS-21-2 (low) No test that `session_at` is Closed on a regular weekend (only holiday). Add Saturday 11:00.
- TS-21-3 (low) Special-session edges untested: 18:00:00 inclusive and 18:59:59; mock boundaries; special on a holiday weekday; `close_time` when a special ends before the regular close; `close_time` on a mock day -> NotTradingDay.
- TS-21-4 (low) UTC/IST date boundary untested: 2026-01-05T18:29:59Z vs 18:30:00Z, and the year boundary 2026-12-31T18:30Z (= 2027-01-01 IST -> OutOfRange).
- TS-21-5 (low) AC4 says no weekday literal in non-test source, but `Weekday::Sat | Weekday::Sun` is at calendar.rs:123 (module doc admits it). Accept and amend the AC wording, or decide otherwise. Not a test defect.
- TS-21-6 (low) Out-of-range not asserted directly for `close_time` and `shift_to_prior_trading_day`.
- TS-21-7 (info) `works_with_clock_instant` is largely redundant; test-only unwraps are acceptable.

## Not verified
Full gate, golden, Playwright (T2 scope); non-2026 fixture years; real config/calendar.toml content.

## Tech-lead decisions (2026-11-19)
- TS-21-5: reject: same as CR-21-1 (wording amended).
- TS-21-1 (medium): defer: F2 calendar-data slice. Green tests already cover every AC4 case; the weak proptest is extra assurance, and F2 loads real holiday/session data where the stronger properties (shift idempotent and never later, lands on a trading day, session_at Closed on non-trading days, all segments, `prev(next(x)) == x`) pay off. Not a correctness defect.
- TS-21-2, TS-21-3, TS-21-4, TS-21-6: defer: F2 calendar-data slice, bundled (Saturday Closed; special edges 18:00:00/18:59:59; UTC/IST boundary 18:29:59Z/18:30:00Z and 2026-12-31T18:30Z OutOfRange; OutOfRange for close_time/shift).
- TS-21-7: reject: info, no action.
