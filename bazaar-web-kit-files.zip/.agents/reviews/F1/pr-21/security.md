# Security review: PR 21 (F1-s3 core-calendar), branch feat/F1-core-calendar

Verdict: PASS
Counts: critical 0, high 0, medium 0, low 0, info 1
Blockers: none

Scope: crates/core/src/calendar.rs (+501 -1). Pure in-memory library code; no I/O, network, secrets, SQL, auth or new dependencies.

## Red-flag hits
All 40 `.unwrap()` hits are inside `#[cfg(test)] mod tests` (lines >= 284). Non-test code has none: errors are `CalendarError` via `?`/`ok_or`.

## Checks
- Panics: none in library code. Date arithmetic uses `succ_opt`/`pred_opt` with error mapping.
- Unbounded loops: `next/prev_trading_day` and `shift_to_prior_trading_day` call `is_trading_day`, which returns `OutOfRange` outside `covered_years`, so every scan terminates (tested).
- Fail-safe: out-of-range year is an error, not "open"; mock session never opens a day; no-session-row is an error.
- No wall-clock reads (instants passed in; test-only `Fixed` clock). Hours, holidays and sessions come from config; only Sat/Sun is a literal (allowed by spec).
- No secrets, logging, or untrusted input handled.

## SEC-21-1 (info): config trust
`from_config` trusts a "validated" config (e.g. special session `end > start`, no overlapping windows). Confirm the config loader enforces these; a malformed window would only mis-report a phase, not break safety. No change required in this PR.

## Tech-lead decision (2026-11-19)
- SEC-21-1: reject: answered. `config/calendar.rs` loader already enforces `start < end` for regular and special sessions (lines ~174, ~231) and rejects overlapping regular sessions (same segment/kind and date range, lines ~188-191), with tests. Special-vs-regular overlap is not checked; the calendar gives precedence to the special, so it cannot mis-open a day.
