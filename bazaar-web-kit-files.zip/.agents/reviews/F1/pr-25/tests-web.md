# Tests review: PR 25 (F1-s8 web-client), area web
Verdict: SIGN-OFF (0 blockers, 2 minors). T0+T1 only.

Run: `pnpm -C web test:ci` -> 6 files, 35 tests pass; coverage 96.3% stmts. `just openapi` regenerated schema.d.ts: `git status` clean, so no drift (guard #16 OK; web/openapi.json not tracked/unchanged).

Criteria mapping (AC10, AC9 part, AC8 part):
- AC10 200 -> PAPER badge text: SessionGate.test "shows the PAPER badge" (text only; colour not asserted, data-mode checked in the semi_auto case). OK.
- AC10 401 -> session-ended screen, no form/button, one call (no retry loop), disclaimer in contentinfo: covered.
- API-error state keeps disclaimer (AC9): covered via network-error test.
- Client: success, 401 -> ApiError + session-ended signal, non-problem body -> "unknown": covered.
- Handlers typed from generated schema: yes.

Not verified: ui-shot / Playwright (binary missing; CI-only), 1280x720 / 1024x600 no-scroll, no sticky/fixed (jsdom cannot assert layout; render tests are an acceptable substitute for T1 but layout stays for CI Playwright).

## Findings
- TS-25-1 (minor): CSRF injection in client.ts onRequest (lines 33-34, the only uncovered lines) is untested: non-GET gets X-CSRF-Token, and a non-GET with no token throws. Security-relevant; no non-GET route exists yet, but add a test with a temporary msw POST handler (or defer to the first mutating slice, noted).
- TS-25-2 (minor): "PAPER ... text + colour" is only asserted by text/data-mode; no assertion that paper vs non-paper differ in class/data attribute beyond data-mode value. Acceptable; optional.
