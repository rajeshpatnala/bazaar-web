# Code review: F1 PR 25 (feat/F1-web-client)

Verdict: APPROVE WITH MINORS. Blockers: none. Major: none.

Checked: generated types only, no innerHTML, CSRF token kept in memory, MSW in tests, disclaimer outside SessionGate, retry is off globally (providers.tsx), PAPER badge uses text plus colour. Red-flag hits are all test `expect`/`unwrap` calls and are fine.

## CR-25-1 minor: `unwrap` throws on an empty success body
web/src/api/client.ts (unwrap). A 204 or empty 2xx has `data === undefined`, so it throws ApiError "unknown". The first non-GET route will hit this. Fix: check `r.response.ok` and `r.error === undefined` before throwing.

## CR-25-2 minor: any 401 triggers session-ended, including a wrong-session call from a non-gate query
web/src/api/client.ts (onResponse). The listener is only used in tests; SessionGate relies on the /auth/me error. A 401 from /status alone (for example the session expiring mid-poll) leaves the shell up with a stale badge. Fix: wire `onSessionEnded` to `queryClient.setQueryData` or invalidate `authMe` in providers, or drop the listener if it is unused.

## CR-25-3 nit: no docs/features record update seen
The diff does not touch docs/features/F1-workspace-bootstrap.md. Add one line on the web client, session gate and mode badge if the slice should be recorded.

## CR-25-4 nit: badge colours are hardcoded hex
web/src/styles.css. Use the existing CSS variables, if any. Contrast looks adequate.
