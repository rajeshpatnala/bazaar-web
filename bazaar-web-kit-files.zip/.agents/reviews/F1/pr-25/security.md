# Security review: PR 25 (F1-s8 web-client), branch feat/F1-web-client

Verdict: PASS. Critical 0, high 0, medium 0, low 1, info 1. Blockers: none.

Note: SEC-F1-1 listed as open in the pack is the CI action-pinning info item (F1/security.md), unrelated to this diff; still open, non-blocking.

## Checked
- CSRF token held in module memory only, never in storage/URL/logs; sent only on non-safe methods; client throws if missing (fail closed).
- Credentials `same-origin`, baseUrl `location.origin`: no cross-origin calls, no SSRF surface.
- 401 handling shows session-ended screen with no form/retry; no secret or token rendered; server `detail` is stored on ApiError but never rendered as HTML (no dangerouslySetInnerHTML).
- Mock fixtures use fake token "test-csrf"; no real secrets. No new dependencies in this diff. No order/trade path added.

## Findings
| id | severity | category | location | issue | fix | status |
|---|---|---|---|---|---|---|
| SEC-25-1 | low | session handling | web/src/api/queries.ts:17-18, web/src/app/ModeBadge.tsx | `statusQuery` polls every 30s from the header badge even after the session has ended (401); `onSessionEnded` is defined but not wired in the app. Harmless 401 noise, no data exposure. | Stop polling when authMe is 401 (enabled flag) or wire onSessionEnded to the query cache. | open (no block) |
| SEC-25-2 | info | hardening | web/src/api/client.ts:30 | `onSessionEnded` listener is a single module-level slot; last registration wins. | Acceptable; document or use a Set if more consumers appear. | open (no block) |
