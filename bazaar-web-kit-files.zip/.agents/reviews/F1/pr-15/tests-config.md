# Test review: PR #15 (F1 slice 2, core config) - area: config

Verdict: SIGN-OFF

- `cargo nextest run -p bazaar-core` on dd9fe1e: 31/31 pass.
- Shipped config/ and fixtures/config/ load (loads_shipped_config, loads_fixture_config); missing file, unknown key with line, header errors covered.
- Risk: ceiling reject (both limits, error names key + "ceiling"), below-ceiling accept, shipped defaults paper/1%/3%, zero/negative/>100 rejected.
- Strict decimals: TOML float and integer for money rejected; strings parsed exactly (decimal_str reads strings only).
- Staleness: within age, too old, per-file override, future-dated, uncovered year, all via explicit `today` (no wall clock).
- applies_to wildcard and kinds, overlap/adjacent sessions, bad times/ranges covered in calendar tests.

Findings: none blocking. Nit (TS-F1-1, low): ceiling exactly-equal is only exercised via shipped defaults, not a dedicated test.
Not verified: clippy/just check, other crates.
