Verdict: APPROVE WITH MINORS

# Code review F1 slice 2 (PR #15, feat/F1-core-config)

Gate result not re-run by me. Diff read in full for config/*.rs, all config/*.toml and the risk/events/charges fixtures; fixtures/config/calendar.toml and watchlists.toml were not opened (the tests that load them were read).

## Checks asked for
- Market facts: no lot/tick/session/holiday literal in Rust. The shipped calendar is empty (`covered_years = []`), so `MarketCalendar` will refuse to answer rather than guess. Fixtures say "synthetic fixture" and use different values from the shipped files. Pass.
- risk.toml keys: `[mode]`, `[limits]` (2 keys), `[hard_limits]` (2 keys) and `[execution]` are all present. The loader checks that every pct is above 0 and at most 100, that each limit is at or below its ceiling, and that cash is above 0. Boundary and error-path tests are present. Pass, but see CR-F1-3.
- Decimal: `decimal_str` reads a string only, so a TOML float or integer fails (tested). No f64 anywhere. Pass.
- `applies_to = "all"`: handled as a loader wildcard, with `covers` and `overlaps` and tests. Pass.
- Staleness: `StalenessPolicy` comes from the caller and `today` is passed in, so there is no clock or env read. It also reports future-dated files and `YearNotCovered`. Pass.
- Panics: every `unwrap` hit is inside `#[cfg(test)]`. Library code uses `?` and `unwrap_or_default`. Pass.

## Findings

- CR-F1-1 (minor, no-hardcode): config/{charges,strategies,data,compliance,events,calendar}.toml:3-5. The placeholder `source` is "owner: placeholder, holds no market data yet; F2 fills it from official sources". This is honest in one respect: it says outright that the file holds no data. Two things are not honest.
  - `verified_on = "2026-11-18"` claims a human compared the file with its sources, but there is nothing to compare. The staleness check will therefore treat these files as fresh for the whole age limit, and only the calendar gets a separate year check.
  - The claim "F2 fills it" is wrong for several files. The code docs name other owners: strategies for `bz-quant`, data for `bz-market-data`, compliance for phase 9 (files.rs:1041-1056). The header comment says "a later feature".
  - Fix: use a per-file source, for example "placeholder: no data; owner bz-quant fills in a later feature". Better, add an explicit `placeholder = true` marker or a sentinel that `stale_warnings` reports, so placeholders are never silently "fresh". Fine to keep `verified_on` as the creation date if the marker exists.
- CR-F1-2 (minor): config/risk.toml and config/watchlists.toml use `source = "owner"` with `verified_on` 2026-11-18. That is fine because the values are owner decisions recorded in the plan.
- CR-F1-3 (question): the hard ceilings live in the same owner-editable file as the limits, so one edit raises both and the loader cannot tell. The file comment says moving a ceiling needs an ADR and owner approval, but nothing enforces it. Please confirm the plan intends file-only ceilings (the risk-guardian would then check this in PR review). Otherwise add a compile-time floor or an audit record.
- CR-F1-4 (minor): `decimal_str` calls `trim()` on the value, so `" 1 "` is accepted. Parse, don't validate suggests rejecting the whitespace. Low impact.
- CR-F1-5 (minor, security): Cargo.lock shows `rust_decimal` pulling `borsh`, `rand` 0.8 and 0.9, `serde_json`, `bytes`, `arrayvec` and `wasm-bindgen`. These are optional features, so the workspace dependency is probably using default or extra features. Consider `default-features = false` with only `std` and `serde`. Pass to the security reviewer (the pack lists Cargo.lock as sensitive).
- CR-F1-6 (nit): `ConfigError::Parse.message` forwards toml's message. That is probably fine, but confirm no config values leak into it, since the module doc says errors never carry file contents.
- CR-F1-7 (minor, records): no `docs/features/F1-*.md` update in this diff. Add it at feature close.

No blockers. No majors.
