# project - code review - docs/project-profile

Verdict: APPROVE WITH MINORS
Round: 1

Checks: file is 50 lines (< 60); no secrets, tokens or .env values; red-flag scan has no hits; all rules restated match CLAUDE.md (Decimal, IST/Clock, no hardcoded market facts, no look-ahead, paper default, DecisionGate + approval, no place-order endpoint, 127.0.0.1 only, session exemptions `/healthz` `/auth` Kite callback, `live-trading` never default, no scraping, agents never touch `data/` or the live broker). Branches `develop` and `main` exist. No contradictions found.

| id | severity | file:line | issue | why it matters | suggested fix | status | tech-lead decision |
|---|---|---|---|---|---|---|---|
| CR-project-1 | minor | .agents/project.md (Deployment and CI) | "Team mode: worktrees" is a point-in-time setting that can change via `just work-mode`; it is not confirmed here against `just preflight`. | The profile could go stale and mislead agents. | Drop the line (work mode lives in team.md / preflight) or confirm it with `just preflight`. | open | |
| CR-project-2 | nit | .agents/project.md (Data stores) | Kite row says "orders later" while the profile says no place-order endpoint. | Consistent only because orders sit behind `live-trading` and the gate; a reader may take it as a contradiction. | Reword to "orders only via gated `live-trading` broker crate (future)". | open | |
| CR-project-3 | question | .agents/project.md (Non-functional targets) | Targets (250 ms p95, 5 s stale, 60 s scan) cannot be checked against the repo. | Fine if owner-supplied; they should be traceable to an NFR or ADR. | Confirm they come from the owner, or point to the NFR doc. | open | |
