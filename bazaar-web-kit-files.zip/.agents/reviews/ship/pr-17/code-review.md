Verdict: APPROVE WITH MINORS

# Code review: ship / PR #17 (chore/ship-keep-branches)

Scope: .claude/kit/kit.py, .agents/team.md, .agents/scripts/kit-smoke.sh (11 lines). Red-flag scan: no hits.

## Checks asked for
- Default is no when the setting is missing or malformed: yes. `team_setting` returns the default when team.md or the row is missing. A malformed value (empty, `maybe`, `true`) is not exactly `yes` after `.lower()`, so nothing is deleted. Only `yes` or `Yes` opts in. Fail-safe.
- No other code path deletes branches: yes. In kit.py the only two sites are the local `git branch -D` and the `--delete-branch` flag, both now gated. The remaining hits are inert `.agents/backup-*/` copies and the smoke script's own cleanup. branch-guard.sh only blocks deletions.
- Parsing matches the other settings: yes. It uses the same `team_setting(name, default).lower() == "yes"` idiom as `light_review_docs` and `envelope_reviews`. The team.md row sits in the same table as `require_ci_checks`.
- Protected-branch guard unchanged: yes. The PR path still requires `head not in (integ, rel)`, and the local path still exits earlier on protected branches.

## Smoke script (run in temp copies via `git archive`, local scratch repos only, no pushes)
- Base: 14 pass, 10 fail. Branch: 14 pass, 10 fail, and `PASS branch kept` appears.
- The extra failure in the developer's 11th count is NOT caused by the change. It comes from running the old smoke script (develop's) against the new kit.py. The old assertion expects the branch to be deleted, so it fails, which is correct for the new default.
- With the branch's own smoke script and kit.py there are 10 failures, the same set as on base. Those 10 are pre-existing and unrelated: checkout warning, review lookup x2, light/security file classes, and the ship/merge-check input validation cases. They fail identically on base.

## Findings
- CR-ship-1 (minor) .agents/scripts/kit-smoke.sh: only the default-no path is covered. There is no case for `delete_merged_branches | yes` that confirms the branch is deleted and that a protected branch is never deleted. Add one, or defer it.
- CR-ship-2 (minor) The 10 pre-existing smoke failures are not caused by this PR but should be triaged separately. The smoke script cannot currently serve as a gate.
- CR-ship-3 (nit) The `ship` PR path passes no `--delete-branch`, but GitHub's repo-level "automatically delete head branches" setting can still delete the remote branch. Confirm that setting is off to fully honour the owner rule. This is outside the PR's code.
