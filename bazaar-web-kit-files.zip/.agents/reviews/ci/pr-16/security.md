Verdict: PASS

# Security review: PR #16 (ci, chore/ci-openapi-drift-guard)

Scope: .github/workflows/ci.yml only (+7 -4). Counts: critical 0, high 0, medium 0, low 1, info 1.

Checked: triggers (unchanged: pull_request, push main/develop), permissions (unchanged: contents: read), secrets (none added or referenced), other jobs (untouched), actions (no new actions, same versions). Red-flag hit at line 128 is a comment only.

## SEC-ci-1 (low, CI integrity): deleting schema.d.ts skips the drift check
The extra hashFiles('web/src/api/schema.d.ts') condition means a PR that deletes (or never adds) the file turns the steps into skips and the job reports green. Realistic for a careless or malicious PR, but low impact: the file is tracked, so the deletion shows in the diff, and the web build/typecheck jobs that import generated types should fail without it, as should code review. Not a silent bypass of the existing state, since today the job is already a no-op (no web/ or server crate yet).
Fix (optional hardening): once schema.d.ts is first committed, replace the hashFiles guard with a hard check, for example `test -f web/src/api/schema.d.ts` when web/package.json exists, so a missing file fails instead of skips.
Verify: open a test PR that deletes the file and confirm the job fails.

## SEC-ci-2 (info)
Step `if:` conditions are repeated five times. Consider a job-level condition or one precheck step to avoid divergence. Not security-relevant.
