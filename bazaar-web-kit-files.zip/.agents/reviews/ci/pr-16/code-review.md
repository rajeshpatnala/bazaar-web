Verdict: APPROVE WITH MINORS

# Code review: PR #16 chore/ci-openapi-drift-guard (feature ci)

Scope: .github/workflows/ci.yml only (+7 -4). No other job touched; the openapi-drift job is kept.

## Checks
- Condition logic: each of the four conditional steps now ANDs `hashFiles('web/src/api/schema.d.ts') != ''`. hashFiles returns '' for no match, so with the schema absent every conditional step is skipped. The only unconditional step is checkout, so the job concludes success (not failed or skipped), and a required check stays satisfied. Once the file is committed, all four steps run and the drift check is live. PASS.
- Consistency: the same expression is on all four steps (rust-toolchain, rust-cache, pnpm/action-setup, drift run). The run step keeps its `name:` and body unchanged. PASS.
- Not a bypass: the guard activates itself by file presence, and nothing is added to ignore failures (no continue-on-error, no job-level if). PASS.
- Red-flag hit (ci.yml:128): the word "bypass" appears only in the comment ("not a bypass"). Justified.

## Findings
- CR-ci-1 (minor) ci.yml:128-130: The comment says the guard activates "once the server `openapi` subcommand and the web `gen:api` script exist", but the condition tests only for the committed schema.d.ts. That is a proxy for those two things, not a check of them. If schema.d.ts is committed before the subcommand exists, the job will run and fail. Reword to say it activates when schema.d.ts is committed, which should only happen alongside them.
- CR-ci-2 (nit) ci.yml:133-141: The same three-clause condition is repeated four times. A single job-level `if:` would be less repetitive, but a skipped job also counts as passing for required checks. Keeping step-level conditions is fine and matches the existing style. No change needed.
- CR-ci-3 (note, by design): while schema.d.ts is absent, drift is not detected. The owner has approved this as intent.

Tests/records: not applicable (CI config only).
