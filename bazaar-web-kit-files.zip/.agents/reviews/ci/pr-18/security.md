Verdict: PASS

# Security review: PR #18 (ci), workflows only

Findings: 0 blocker, 0 medium. 2 info.

Checks
- Permissions/triggers: unchanged. ci.yml stays `contents: read`, triggers `pull_request` + push develop/main (no pull_request_target). release.yml stays push to main only, with contents/pull-requests/packages write at workflow level (pre-existing).
- Secrets: only the auto GITHUB_TOKEN is used; no new secrets or echoes.
- Release gating: release.yml triggers only on push to main. publish-image still needs release-please and release_created == 'true', so it cannot run on PRs or forks (fork PRs do not trigger release.yml at all).
- hashFiles moved to step-level `if`: the job now runs checkout when no Dockerfile exists, but login and push are skipped; no extra exposure.
- Concurrency: cancel-in-progress only for pull_request; no security effect.
- macOS test now `if: push`: Linux `test` still runs on every PR. Only the Keychain (macOS-only) compile path is unchecked on PRs and is checked on push to develop/main, so it is caught after merge. Accepted, low (info SEC-ci-1).

Info
- SEC-ci-1: macOS-only code is validated post-merge, not pre-merge. Keep an eye on develop failures.
- SEC-ci-2: In publish-image, `${{ needs.release-please.outputs.tag_name }}` is interpolated into the shell script (pre-existing). The value comes from release-please (vX.Y.Z), not user input, so the risk is negligible. Optionally pass it via `env:`.

Owner action: "Allow GitHub Actions to create and approve pull requests"
Acceptable for a solo private repo. release-please needs it to open the release PR. Risk: any workflow could approve PRs, which weakens review-by-another-person, but there is no second reviewer in a solo repo anyway. Keep branch protection on main/develop (required checks) so approval alone cannot bypass the CI gate. Do not enable it org-wide; set it only on this repo. Alternative is a fine-grained PAT, which is a bigger secret to manage, so the setting is the better choice.
