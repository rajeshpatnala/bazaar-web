Verdict: APPROVE WITH MINORS

# Code review: ci / PR #18 (chore/ci-release-and-macos)

Scope: .github/workflows/ci.yml (+6 -1), .github/workflows/release.yml (+6 -3). Nothing else changed. Red-flag scan: no hits.

## Checks
- release.yml expression validity: `hashFiles()` is not available in a job-level `if` (only github, needs, vars, inputs contexts), so the old form invalidated the workflow. At step level it is valid (steps `if` allows hashFiles). The job-level `if` keeps the `release_created == 'true'` check. YAML shape (`- if:` before `uses:`/`name:`) is fine.
- publish-image semantics: with a Dockerfile present, behaviour is identical (login and build/push both run). Without one, the job still runs and checks out, but login and build are skipped, so it reports success instead of "skipped". Acceptable and arguably intended.
- ci.yml `test-macos`: `if: github.event_name == 'push'` is valid. Other jobs have no `if` added or removed, so Linux `test` stays the PR gate and nothing else is weakened.
- Concurrency: `cancel-in-progress: ${{ github.event_name == 'pull_request' }}` evaluates to a boolean and is valid. The group is per ref, so PR runs cancel only their own earlier runs; develop/main push runs are not cancelled. Queued (pending) push runs are still replaced by newer ones, which is fine.

## Findings
- CR-ci-1 (nit): release.yml, publish-image. If Dockerfile is absent, the job goes green having done nothing. Consider a one-line `echo` step with `if: hashFiles('Dockerfile') == ''` so the log says why. Optional.
- CR-ci-2 (nit, question for owner): macOS now runs only after merge, so a macOS-only compile break (Keychain store) is found post-merge. This is the owner-approved tradeoff; confirm a failed push run on develop is watched.

blockers: none | major: none | minor: 0 | nit: 2
