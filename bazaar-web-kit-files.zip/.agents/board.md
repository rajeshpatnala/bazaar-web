# Board

Maintained by the manager. One row per task; newest feature first. Statuses: todo, planning, building, gate, review, fixing, ready-to-merge, merged, blocked, deferred.

## Resume




2026-11-19: F1 PR 25 merged. PR 24 approved by code, security, tests but merge-check needs line 2 of tests-server.md in tester worktree to start Verdict: SIGN-OFF - owner edits it, then tech lead runs just ship 24, then docs branch with PR 24 and 25 deferrals and BAZAAR_PORT note. NEXT slice 9, then F2 per plan F2-market-data-foundation.md, 4 owner questions pending.

## Owner actions

<!-- Things only the owner can do. One line each: - [ ] <what> (<where>) - since <date> -->
- [ ] Supply NSE holiday list and session timings with circular ids/URLs (docs/owner-input/F2-calendar.md) - since 2026-11-19
- [ ] Supply Zerodha charges page text or screenshot plus one redacted contract note (docs/owner-input/F2-charges.md) - since 2026-11-19


## Tasks

| id | feature | slice / task | agent | branch / PR | status | blocker / next step |
|---|---|---|---|---|---|---|
| CI-1 | #16 openapi-drift guard, #17 keep merged branches, #18 release.yml + macOS | cicd/dev-core | merged | merged | all three merged by owner 2026-11-18. just ship no longer deletes branches. Owner action pending: enable Settings>Actions>General "Allow GitHub Actions to create and approve pull requests" for release-please |
| F1-s6 | server-wiring | slice 6 | dev-api | feat/F1-server-wiring / PR 22 | merged 1037c5f | owner: start in the new session with slice 3. Needs 1+5 (merged). Must include router-level 401-on-every-route test (CR-F1-S5-1), wrap security_headers outermost via from_fn, from_fn(security::security_headers) |
| F1-s7 | server-startup | slice 7 | dev-api | PR 24 | merged 8d74a5f | docs PR with PR 24/25 deferrals in progress (tech lead) |
| F2 | market-data-foundation | plan approved 2026-11-19 | tech-lead | .agents/plans/F2-market-data-foundation.md | todo | owner approved scope offline, deps sqlx/csv/sha2/tempfile; slices 6,7 wait for owner inputs |
